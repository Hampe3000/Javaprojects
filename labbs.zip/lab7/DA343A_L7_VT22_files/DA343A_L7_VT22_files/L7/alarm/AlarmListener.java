package L7.alarm;

public interface AlarmListener {
	public void alarm();
}
