package L7.alarm;

public class DemoAlarm implements AlarmListener {
	public DemoAlarm(int ms){
		AlarmThread at = new AlarmThread(ms);
		at.addAlarmListener(this);
		at.addAlarmListener(new wakeUpPrinter());
		at.startAlarm();
	}

	@Override
	public void alarm() {
		System.out.println("ALARM!");
	}

	public static void main(String[] args) {

		DemoAlarm da = new DemoAlarm(4000);

	}

	private class wakeUpPrinter implements AlarmListener{
		@Override
		public void alarm() {
			System.out.println("WAKE UP!");
		}
	}
}
