package L7.alarm;

import java.util.LinkedList;

public class AlarmThread{
	private Thread thread;
	private long ms;
	private LinkedList<AlarmListener> listeners;

	public AlarmThread(long ms) {
		listeners = new LinkedList<AlarmListener>();
		this.ms = ms;
	}

	public void addAlarmListener(AlarmListener listener){
		listeners.add(listener);
	}

	public void startAlarm() {
		if(thread==null) {
			thread = new AT();
			thread.start();
		}
	}

	private class AT extends Thread {
		public void run() {
			try {
				Thread.sleep(ms);
			}catch(InterruptedException e) {

			}
			//System.out.println("Nu är det dags att gå upp!");
			for (int i = 0; i < listeners.size(); i++) {
				listeners.get(i).alarm();
			}
			thread = null;
		}
	}
}
