package L8;

import java.util.LinkedList;

public class StringBuffer {
    private LinkedList<String> buffer;

    public StringBuffer(){
        buffer = new LinkedList<String>();
    }

    public synchronized void put(String str){
        buffer.addLast(str);
        notifyAll();
    }

    public int getSize(){
        return buffer.size();
    }

    public synchronized String get() throws InterruptedException{
        if (buffer.size() == 0){
            wait();
        }
        return buffer.removeFirst();
    }
}
