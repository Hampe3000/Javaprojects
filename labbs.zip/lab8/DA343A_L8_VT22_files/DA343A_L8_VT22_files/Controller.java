package L8;

import java.io.File;

public class Controller {
	private StringBuffer buffer;

	public Controller(StringBuffer buffer) {
		this.buffer = buffer;
		File file = new File("files/Material 6");
		ZipArchive th1 = new ZipArchive(file, buffer);
		Messages th2 = new Messages();
		th1.run();
		th2.run();
		/*StringProducer th1 = new StringProducer(buffer);
		StringConsumer th2 = new StringConsumer(buffer);
		//Starta tråd
		th1.run();
		th2.run();*/
	}

	// inre class som är en tråd
	private class StringProducer extends Thread{
		private StringBuffer buffer;

		public StringProducer(StringBuffer buffer){
			this.buffer = buffer;
		}

		@Override
		public void run() {
			String[] arr = {"Hej", "du", "glade", "tag", "en", "spade", "..."};
			System.out.println("String producer runs");
			for (int i = 0; i < arr.length; i++) {
				try{
					sleep(500);
				}
				catch (Exception e){}
				buffer.put(arr[i]);
			}
		}
	}
	// tråden ska hämta String-objekt ur buffer och placerar dem i TextWindow
	private class StringConsumer extends Thread{
		private StringBuffer buffer;

		public StringConsumer(StringBuffer buffer){
			this.buffer = buffer;
		}

		@Override
		public void run() {
			String str;
			System.out.println("String consumer is running");
			while (!Thread.interrupted()){
				try {
					str = buffer.get();
					System.out.println(str);
				}
				catch (InterruptedException e){
					break;
				}
			}
		}
	}

	private class Messages extends Thread{
		@Override
		public void run() {
			String str;
			TextWindow tw = new TextWindow();
			while (!Thread.interrupted()){
				try{
					str = buffer.get();
					tw.println(str);
				}catch (InterruptedException e){break;}
			}
		}
	}

	public static void main(String[] args){
		new Controller(new StringBuffer());
	}
}
