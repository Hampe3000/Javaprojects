package Model.client;


import javax.swing.*;
import java.io.Serializable;
import java.util.ArrayList;

public class User implements Serializable {
    private String userName;
    private ImageIcon profilePic;
    private String password;
    private Status currentStatus;
    private String statusName;
    private ArrayList<User> contacts;
    private ArrayList<Chat> chats;
    private ArrayList<User> usersOnline;

    public User(String userName, ImageIcon profilePic, String password, Status currentStatus, String statusName, ArrayList<User> contacts, ArrayList<Chat> chats, ArrayList<User> usersOnline) {
        this.userName = userName;
        this.profilePic = profilePic;
        this.password = password;
        this.currentStatus = currentStatus;
        this.statusName = statusName;
        this.contacts = contacts;
        this.chats = chats;
        this.usersOnline = usersOnline;
    }

    public void updateOtherUsersStatus(User user){
        boolean found = false;
        for (int i = 0; i < contacts.size(); i++) {
            if(user.getUserName().equals(contacts.get(i).getUserName())){
                contacts.set(i, user);
                found = true;
                break;
            }
        }

        if(!found){
            for (int i = 0; i < usersOnline.size(); i++) {
                if(user.getUserName().equals(usersOnline.get(i).getUserName())){
                    if(user.getCurrentStatus() == Status.online){
                        usersOnline.set(i, user);
                    }else{
                        usersOnline.remove(i);
                    }
                    found = true;
                    break;
                }
            }
        }
        if(!found && user.getCurrentStatus() == Status.online){
            usersOnline.add(user);
        }
    }

    public void addContact(User contact){
        contacts.add(contact);
    }

    public void removeContact(User contact){
        for (int i = 0; i < contacts.size(); i++) {
            if(contact.getUserName().equals(getContacts().get(i).getUserName())){
                contacts.remove(i);
                break;
            }
        }
    }

    public void updateChats(Chat chat){
        boolean found = false;
        for (int i = 0; i < chats.size(); i++) {
            if(chat.getChatID() == (chats.get(i).getChatID())){
                chats.set(i, chat);
                found = true;
                break;
            }
        }
        if(!found){
            chats.add(chat);
        }
    }

    public void removeChat(Chat chat){
        for (int i = 0; i < chats.size(); i++) {
            if(chat.getChatID() == (chats.get(i).getChatID())){
                chats.remove(i);
                break;
            }
        }
    }

    //GETTER AND SETTER
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public ImageIcon getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(ImageIcon profilePic) {
        this.profilePic = profilePic;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Status getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(Status currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public ArrayList<User> getContacts() {
        return contacts;
    }

    public void setContacts(ArrayList<User> contacts) {
        this.contacts = contacts;
    }

    public ArrayList<Chat> getChats() {
        return chats;
    }

    public void setChats(ArrayList<Chat> chats) {
        this.chats = chats;
    }

    public ArrayList<User> getUsersOnline() {
        return usersOnline;
    }

    public void setUsersOnline(ArrayList<User> usersOnline) {
        this.usersOnline = usersOnline;
    }

}


