package Model.client.Request;


import Model.client.Message;

/* This class can add or delete a message*/

public class MessageRequest extends Request {
    private Message message;

    public MessageRequest(RequestType requestType, Message message) {
        super(requestType);
        this.message = message;
    }

    public Message getMessage() {
        return message;
    }
}
