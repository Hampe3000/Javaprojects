package Model.client.Request;

import Model.client.Status;


public class StatusStringRequest extends Request {
    private String newUsername;
    private Status status;

    public StatusStringRequest(RequestType requestType, String newUsername, Status status) {
        super(requestType);
        this.newUsername = newUsername;
        this.status = status;
    }

    public String getNewUsername(){
        return newUsername;
    }
}
