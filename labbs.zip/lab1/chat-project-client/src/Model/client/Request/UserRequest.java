package Model.client.Request;

import Model.client.User;


public class UserRequest extends Request {
    private User user;

    public UserRequest(RequestType requestType, User usel) {
        super(requestType);
        user = usel;
    }

    public User getUser() {
        return user;
    }
}
