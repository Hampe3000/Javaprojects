package Model.client.Request;

import javax.swing.*;

public class ImageIconRequest extends Request {
    private ImageIcon newProfilePic;

    public ImageIconRequest(RequestType requestType, ImageIcon newProfilePic) {
        super(requestType);
        this.newProfilePic = newProfilePic;
    }

    public ImageIcon getNewProfilePic(){
        return newProfilePic;
    }
}
