package Model.client.Request;

/* This class is a request for the server when someone wants to login or register to the application */

public class DoubleStringRequest extends Request {
    private String username;
    private String password;

    public DoubleStringRequest(RequestType requestType, String username, String password) {
        super(requestType);
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
