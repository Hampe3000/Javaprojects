package Model.client;

import java.io.Serializable;
import java.util.ArrayList;

public class Chat implements Serializable {
    private ArrayList<User> participants;
    private ArrayList<Message> messages;
    private int chatID;
    private String nameOfChat;

    public Chat(ArrayList<User> participants, ArrayList<Message> messages, String nameOfChat) {
        this.participants = participants;
        this.messages = messages;
        chatID = -1;
        this.nameOfChat = nameOfChat;
    }



    public void addParticipant(User user){
        participants.add(user);
    }

    public void removeParticipant(User usel){
        for (int i = 0; i < participants.size(); i++) {
            if(participants.get(i).getUserName().equals(usel.getUserName())){
                participants.remove(i);
                break;
            }
        }
    }

    public void addMessage(Message msg){
        messages.add(msg);
    }

    public void removeMessage(Message msg){
        for (int i = 0; i < messages.size(); i++) {
            if(messages.get(i).getTimeSend() == msg.getTimeSend()){
                messages.remove(i);
                break;
            }
        }

    }

    // GETTER AND SETTER
    public ArrayList<User> getParticipants() {
        return participants;
    }

    public void setParticipants(ArrayList<User> participants) {
        this.participants = participants;
    }

    public ArrayList<Message> getMessages() {
        return messages;
    }

    public int getChatID() {
        return chatID;
    }

    public void setChatID(int chatID) {
        this.chatID = chatID;
    }

    public void setMessages(ArrayList<Message> messages) {
        this.messages = messages;
    }

    public String getNameOfChat() {
        return nameOfChat;
    }

    public void setNameOfChat(String nameOfChat) {
        this.nameOfChat = nameOfChat;
    }
}
