package Controller;

import Model.client.*;
import Model.client.Request.DoubleStringRequest;
import Model.client.Request.Request;
import Model.client.Request.RequestType;
import Model.client.Request.UserRequest;
import View.MainMenu.*;
import View.Login.*;
import View.Chat.*;


import View.Register.RegisterFrame;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;



public class Controller {
    private Client client;
    private User currentUser;
    private Message message;
    private LoginMainFrame loginMainFrame;
    private MainMenuMainFrame mainMenuMainFrame;
    private ArrayList<MainFrameChat> mainFrameChats;
    private RegisterFrame registerFrame;

    public Controller() {
        // Login
        loginMainFrame = new LoginMainFrame(this, 800, 600);

        //register
        //RegisterFrame regg = new RegisterFrame(this,400,600);

        // Main menu
        // MainMenuMainFrame mainFrame = new MainMenuMainFrame(this, 1000, 800);

        // Chat window
        //MainFrameChat mainFrame = new MainFrameChat(this, 800, 600);

        // Demo of main menu
        // MainMenuDemo();

        start();
    }

    /*private void MainMenuDemo() {
        MainMenuMainFrame mainMenuMainFrame = new MainMenuMainFrame(this, 1000, 800);
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addOnlineUser(new OnlineUser(this, "Name A", true));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addOnlineUser(new OnlineUser(this, "Name B", true));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addOnlineUser(new OnlineUser(this, "Name C", false));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addOnlineUser(new OnlineUser(this, "Name D", false));

        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addContactUser(new ContactUser(this, "Name A", Color.green));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addContactUser(new ContactUser(this, "name B", Color.green));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addContactUser(new ContactUser(this, "Name C", Color.red));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addContactUser(new ContactUser(this, "Name D", Color.blue));



    }*/

    public void start(){
        client = new Client(this,"localhost",1337);
        loginMainFrame = new LoginMainFrame(this, 800, 600);
        System.out.println(loginMainFrame.isShowing());
        System.out.println("halllååå");
    }

    public void login(String username, char[] password){
        start();
        String strPassword = null;
        for (int i = 0; i < password.length; i++) {
            strPassword += password[i];
        }
        Request request = new DoubleStringRequest(RequestType.login, username, strPassword);
        client.sendRequest(request);
    }

    public void register(){
        loginMainFrame.dispose();
        registerFrame = new RegisterFrame(this, 400, 600);
    }

    public void registerNewUser(String userName, char[] password, String image){
        String strPassword = "";
        for (int i = 0; i < password.length; i++) {
            strPassword += password[i];
        }
        User user = new User(userName, new ImageIcon(image), strPassword, Status.online, "Online", new ArrayList<User>(), new ArrayList<Chat>(), new ArrayList<User>());
        Request request = new UserRequest(RequestType.register, user);
        start();
        client.sendRequest(request);
    }

    public void response(Object obj){
        if(obj instanceof User){
            if(currentUser == null){
                currentUser = (User) obj;
                loginMainFrame.dispose();
                registerFrame.dispose();
                mainMenuMainFrame = new MainMenuMainFrame(this, 800, 600);
            }
            currentUser.updateOtherUsersStatus((User) obj);
            updateOtherUserInfo();
        }
        else if(obj instanceof String){
            loginFailed((String) obj);
        }
        else if(obj instanceof Chat){
            currentUser.updateChats((Chat) obj);
            updateChat((Chat) obj);
            //play sound effect
        }

    }

    public void loginFailed(String failure){
        if(failure.equals("Wrong password")){
            loginMainFrame.displayLoginError("Wrong password!");
        }

        else if(failure.equals("Non existing user")){
            loginMainFrame.displayLoginError("User does not exist, please create a new user!");
        }

        else if(failure.equals("Username already taken")){
            loginMainFrame.displayLoginError("Sadly this username is already in use by someone else :(");
        }

        else {
            System.err.println("Unknown failure");
        }
    }

    public void updateOtherUserInfo(){
        ArrayList<ContactUser> contactList = new ArrayList<ContactUser>();
        ArrayList<User> myContacts = currentUser.getContacts();
        for (int i = 0; i < myContacts.size(); i++) {
            String name = myContacts.get(i).getUserName();
            Color color = null;
            switch(myContacts.get(i).getCurrentStatus()){
                case online:
                    color = Color.GREEN;
                    break;
                case offline:
                    color = Color.GRAY;
                    break;
                case invisible:
                    color = Color.GRAY;
                    break;
                case do_not_disturb:
                    color = Color.RED;
                    break;
            }
            contactList.add(new ContactUser(this, name, color));
        }

        ArrayList<User> theOthers = currentUser.getUsersOnline();
        ArrayList<OnlineUser> onlineUsers = new ArrayList<OnlineUser>();
        for (int i = 0; i < theOthers.size(); i++) {
            String name = theOthers.get(i).getUserName();
            onlineUsers.add(new OnlineUser(this, name, true));
        }

        mainMenuMainFrame.updateUsers(contactList, onlineUsers);
    }

    public void updateChat(Chat chat){


        //todo loop through the active chat windows if they are using the current chat id update
        for (int i = 0; i < mainFrameChats.size(); i++) {

        }

        String[] chats = new String[currentUser.getChats().size()];
        for (int i = 0; i < currentUser.getChats().size(); i++) {
            int åp = currentUser.getChats().get(i).getMessages().size();
            chats[i] = currentUser.getChats().get(i).getNameOfChat() + "\n" +
                    currentUser.getChats().get(i).getMessages().get(åp).getSender().getUserName() + ", Time sent: " +
                    currentUser.getChats().get(i).getMessages().get(åp).getTimeSend();
        }
        mainMenuMainFrame.updateChats(chats);
    }

    public void displayChat() {
       int index =  mainMenuMainFrame.getMainMenuMainPanel().getLeftPanel().getChatIndex();
       int id = currentUser.getChats().get(index).getChatID();
       mainFrameChats.add(new MainFrameChat(this, 800, 600 , id));
       updateChat(currentUser.getChats().get(index));
    /*Checks if the current user is the sender*/
    }

    public boolean messageDialogUpdate(){
        boolean isMyMessage = false;
        if(currentUser.equals(message.getSender())){
            isMyMessage = true;
        }
        return isMyMessage;
    }
}
