package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.util.ArrayList;

public class LeftPanel extends JPanel {

    private Controller controller;
    private int width;
    private int height;

    // Object lists

    private JScrollPane jScrollPane;
    private JList<String> chatsList;

    public LeftPanel(Controller controller, int width, int height){
        super(new BorderLayout());
        this.controller = controller;
        this.width = width;
        this.height = height;

        setup();
    }

    private void setup() {

        // Chats object list
        chatsList = new JList<String>();
        chatsList.setLocation(0, height / 8);
        chatsList.setSize(width / 2, height - (height / 4));

        JScrollPane chatsListScroll = new JScrollPane();
        chatsListScroll.setViewportView(chatsList);
        chatsListScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        chatsListScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        // chatsList.setLayoutOrientation(JList.VERTICAL);
        // Todo: Add action listener
        chatsList.addListSelectionListener(l -> controller.displayChat());
        this.add(chatsListScroll);

    }

    public void updateChatList(String[] chats){
        chatsList.setListData(chats);
    }

    public int getChatIndex(){
        return chatsList.getSelectedIndex();
    }
}
