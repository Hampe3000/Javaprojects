package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

public class ContactUser extends JPanel {

    private Controller controller;
    private String name;
    private Color statusColor;

    private JLabel nameLabel;
    private JPanel linePanel;

    public ContactUser(Controller controller, String name, Color statusColor) {
        super(new BorderLayout());
        this.controller = controller;
        this.name = name;
        this.statusColor = statusColor;

        setup();
    }

    private void setup() {
        this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.setBackground(Color.white);

        JPanel profile = new JPanel(new GridLayout(0, 3));
        profile.setBackground(Color.white);

        nameLabel = new JLabel(name);
        linePanel = new JPanel(new BorderLayout());
        linePanel.setBackground(Color.WHITE);

        JPanel n = new JPanel();
        n.setBackground(statusColor);
        linePanel.add(n, BorderLayout.WEST);

        profile.add(nameLabel);
        profile.add(linePanel);
        profile.add(new JButton("View chats"));

        this.add(profile);
    }

}
