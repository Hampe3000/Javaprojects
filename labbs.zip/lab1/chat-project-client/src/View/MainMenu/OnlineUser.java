package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

public class OnlineUser extends JPanel {

    private Controller controller;
    private String name;
    private boolean isNotContact;

    private JLabel nameLabel;
    private JButton button;

    public OnlineUser(Controller controller, String name, boolean isNotContact) {
        super(new BorderLayout());
        this.controller = controller;
        this.name = name;
        this.isNotContact = isNotContact;

        setup();
    }

    private void setup(){
        this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.setBackground(Color.white);

        JPanel profile = new JPanel(new GridLayout(0, 2));
        profile.setBackground(Color.white);

        nameLabel = new JLabel(name);
        button = new JButton("Add");
        button.setEnabled(isNotContact);

        profile.add(nameLabel);
        profile.add(button);

        this.add(profile, BorderLayout.CENTER);
    }

}
