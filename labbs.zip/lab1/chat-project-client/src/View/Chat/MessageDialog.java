package View.Chat;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

public class MessageDialog extends JPanel {

    private int height;
    private int width;
    private Controller controller;
    private boolean isMyMessage;
    private String text;
    private String sender;
    private String time;

    public MessageDialog(Controller controller, int height, int width, String sender, String text, String time){
        this.controller = controller;
        this.height = height;
        this.width = width;
        this.sender = sender;
        this.text = text;
        this.time = time;

        setUp();
    }

    public void setUp(){

        //Panel
        JPanel panel = new JPanel();
        panel.setSize(height,width);

        if(controller.messageDialogUpdate()){
            panel.setBackground(Color.GREEN);
        }
        else{
            panel.setBackground(Color.BLUE);
        }
        panel.setVisible(true);

        //Sender
        JLabel sender = new JLabel();
        sender.setText(this.sender);
        panel.add(sender);
        sender.setVisible(true);

        //Message
        JLabel message = new JLabel();
        message.setText(this.text);
        panel.add(message);
        message.setVisible(true);

        //TimeSent
        JLabel timeSent = new JLabel();
        timeSent.setText(this.time);
        panel.add(timeSent);

        timeSent.setVisible(true);

    }

}