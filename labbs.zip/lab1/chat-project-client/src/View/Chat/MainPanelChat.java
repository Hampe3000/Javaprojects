package View.Chat;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import Controller.Controller;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/* This class is the frame of the conversation and also where everything is set,
* maybe we dont need class CharPanel? */
public class MainPanelChat extends JPanel {
    private Controller controller;
    private int width;
    private int height;

    //Conversation window
    private JPanel conversationWindow;
    private JList<Object> messages;
    private JScrollPane scroll;

    //Participant list
    private JList<Object> participants;
    private JScrollPane listScroll;

    //Message Box
    private JTextPane textArea;
    private int x;
    private int y;
    private JPanel messageBoxPanel;
    private JScrollPane textAreaScroll;

    //Buttons
    private JButton sendBtn;
    private JFileChooser addPic;
    private JButton sendPic;
    private JButton addToChat;
    private JButton leaveChat;


    public MainPanelChat(Controller controller, int width, int height) {
        super(null);
        this.setBackground(new Color(190,228,253)); // sätter bakgrunden för panelen ifall vi är intresserade av det
        this.controller = controller;
        this.width = width;
        this.height = height;

        setUp();

    }
    /* This method sets the whole chat-window */
    public void setUp() {

        // conversation window.
        conversationWindow = new JPanel();
        conversationWindow.setLocation(0,0);
        conversationWindow.setSize(3*width/4, (3*height)/4);
        conversationWindow.setBackground(Color.gray);
        conversationWindow.setLayout(new BorderLayout());
        this.add(conversationWindow);

       //List of conversations with scroll
        messages = new JList<Object>();
        messages.setBackground(new Color(235,230,245));
        scroll = new JScrollPane();
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setViewportView(messages);
        conversationWindow.add(scroll);

      // Text field for writing messages
        messageBoxPanel = new JPanel(new BorderLayout());
        messageBoxPanel.setLocation(5,((3*height)/4)+5);
        messageBoxPanel.setSize(width/2, (height/6)+2);
        messageBoxPanel.setBackground(new Color(190,228,253));

        textArea = new JTextPane();
        textArea.setBounds(x,y,width,height);
        textArea.setPreferredSize(new Dimension(380,100));
        textArea.setEditable(true);

        textArea.setFont(new Font("Serif", Font.BOLD, 14));
        textArea.setBackground(new Color(245,217,245));
        textArea.setBorder(new LineBorder(Color.WHITE,3));

        textAreaScroll = new JScrollPane(textArea);
        textAreaScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        textAreaScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        messageBoxPanel.add(textAreaScroll, BorderLayout.WEST);
        this.add(messageBoxPanel);

        //Send button, when button is pressed, the written message will be sent
        sendBtn = new JButton("SEND MESSAGE");
        sendBtn.setLocation((width/4)*2 +15,((3*height)/4)+5);
        sendBtn.setSize(width/5,height/14);
        sendBtn.setFont(new Font("Arial", Font.PLAIN, 13));
       // sendBtn.addActionListener(l -> controller.sendMessage());
        this.add(sendBtn);

        //Button for fileChooser, when button is pressed a fileChooser will open and you choose a image to send
        sendPic = new JButton("CHOOSE PICTURE");
        sendPic.setLocation((width/2)+15,10*(height/12) +5);
        sendPic.setSize(width/5,height/14);
        sendPic.setFont(new Font("Arial", Font.PLAIN, 13));
        sendPic.addActionListener(l -> openFileChooser());
        this.add(sendPic);

        //Button for add a new person to a chat conversation
        addToChat = new JButton("ADD PARTICIPANT");
        addToChat.setLocation(3*(width/4), 6*(height/8)+5);
        addToChat.setSize(width/5,height/14);
        addToChat.setFont(new Font("Arial", Font.PLAIN, 13));
     //   addToChat.addActionListener(l -> controller.addNewPersonToChat());
        this.add(addToChat);

        //Button for leaving the chat for ever
        leaveChat = new JButton("LEAVE CHAT");
        leaveChat.setLocation(3*(width/4),10*(height/12)+5);
        leaveChat.setSize(width/5,height/14);
        leaveChat.setFont(new Font("Arial", Font.PLAIN, 13));
      //  leaveChat.addActionListener(l -> controller.leaveCurrentChat());
        this.add(leaveChat);

        //List for all participants in the chat, only show
        JPanel participantsPanel = new JPanel();
        participantsPanel.setLocation(3*(width/4),0);
        participantsPanel.setSize((width/4)-15 ,(3*height)/4);
        participantsPanel.setLayout(new BorderLayout());
        this.add(participantsPanel);

        participants = new JList<Object>();
        participants.setBackground(new Color(231,220,247));
        listScroll = new JScrollPane();
        listScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        listScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        listScroll.setViewportView(participants);
        participantsPanel.add(listScroll);
    }

    /*Method that will be called when JButton for send a picture is pressed, opens the file chooser*/
    private void openFileChooser() {
        System.out.println("Pressed!");
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Filters for images", "jpeg", "png");
        fileChooser.setFileFilter(filter);
        fileChooser.showOpenDialog(null);
        System.out.println(fileChooser.getSelectedFile().getAbsolutePath());
    }

    private void InsertIcon(Icon icon){
        // kolla om metoden fungerar för att skicka bilder och lägga
        // in dom i textPane
    }

    }



