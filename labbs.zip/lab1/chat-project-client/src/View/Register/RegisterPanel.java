package View.Register;

import Controller.Controller;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;

public class RegisterPanel extends JPanel {
    private Controller controller;
    private int width;
    private int height;

    private JLabel userNameLbl;
    private JTextField userName;
    private JLabel passwordLbl;
    private JPasswordField password;
    private JButton registerBtn;
    private JButton userPicture;

    public RegisterPanel(Controller controller, int width, int height) {
        super(null);
        this.controller = controller;
        this.width = width;
        this.height = height;
        this.setBackground(new Color(13, 133, 150));
        setUp();
    }

    public void setUp() {

        userNameLbl = new JLabel("Select a username");
        userNameLbl.setLocation(100,(height/8));
        userNameLbl.setSize(width/3,20);
        this.add(userNameLbl);

        userName = new JTextField();
        userName.setLocation(100,height/6);
        userName.setSize(200,50);
        userName.setEnabled(true);
        userName.setFont(new Font("Arial", Font.PLAIN, 16));
        userName.setBackground(new Color(124,200,210));
        this.add(userName);


        passwordLbl = new JLabel("Select a password");
        passwordLbl.setLocation(100,(height/10)*3);
        passwordLbl.setSize(width/3,20);
        this.add(passwordLbl);

        password = new JPasswordField();
        password.setLocation(100,2*(height/6));
        password.setSize(200,50);
        password.setEnabled(true);
        password.setFont(new Font("Arial", Font.PLAIN, 16));
        password.setBackground(new Color(124,200,210));
        this.add(password);


        userPicture = new JButton("Select picture");
        userPicture.setLocation(100, 3*(height/6));
        userPicture.setSize(200,50);
        userPicture.setFont(new Font("Arial", Font.PLAIN, 13));
        userPicture.addActionListener(l -> openProfilPic());
        this.add(userPicture);


        registerBtn = new JButton("Register");
        registerBtn.setLocation(100,4*(height/5));
        registerBtn.setSize(200,50);
        registerBtn.setFont(new Font("Arial", Font.PLAIN, 13));
        registerBtn.addActionListener(l -> controller.registerNewUser(userName.getText(), password.getPassword(), openProfilPic()));
        this.add(registerBtn);
    }

    private String openProfilPic() {
        System.out.println("Pressed!");
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Filters for images", "jpeg", "png");
        fileChooser.setFileFilter(filter);
        fileChooser.showOpenDialog(null);
        return fileChooser.getSelectedFile().getAbsolutePath();
    }
}

