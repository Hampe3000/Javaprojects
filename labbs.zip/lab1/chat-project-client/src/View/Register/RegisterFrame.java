package View.Register;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

public class RegisterFrame extends JFrame {
    private Controller controller;
    private int width;
    private int height;
    private RegisterPanel regPanel;


    public RegisterFrame(Controller controller, int width, int height) {
        super("Welcome to Ingvar02 Chat Service ");
        this.controller = controller;
        this.width = width;
        this.height = height;

        this.setResizable(false);
        this.setSize(width, height);
        this.setLocationRelativeTo(null);
        regPanel = new RegisterPanel(controller, width, height);
        this.setContentPane(regPanel);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }



}
