package laboration1;

public class DString implements DynamicString { // implementera metoderna i DynamicString - se lab
	private char[] text;
	private int length = 0;
	
	public DString() {
		this(10);
	}
	
	public DString(int size) {
		size = (size<=0) ? 10 : size;
		text = new char[size];
		length = 0;
	}
	
	public DString(String str) {
		text = str.toCharArray();
		length = text.length;
	}
	
	public DString(DString str) {
		text = new char[str.length()];
		for(int i=0; i<str.length(); i++) {
			text[i] = str.charAt(i);
		}
		length = text.length;
	}
	
	private void grow() {
		char[] newArr = new char[length*2];
		System.arraycopy(text, 0, newArr, 0, text.length);
		text = newArr;
	}
	
	public DString append(char chr) {
		if(length==text.length) {
			grow();
		}
		text[length++] = chr;
		return this;
	}

	@Override
	public int length() {
		return length;
	}

	@Override
	public char charAt(int index) {
		return text[index];
	}

	public String toString(){
		String textToString = "";
		for (int i = 0; i < length; i++) {
			textToString += text[i];
		}
		return textToString;
	}

	@Override
	public DString append(DString str) {
		for (int i = 0; i < str.length(); i++) {
			if(length == text.length){
				grow();
			}
			text[length] = str.charAt(i);
			length++;
		}
		return this;
	}

	@Override
	public DString delete(int start, int end) {
		for (int i = start; i < end ; i++) {
			delete(start);
		}
		return this;
	}

	@Override
	public DString delete(int index) {
		for (int i = index; i < length - 1; i++) {
			text[i] = text[i+1];
		}
		length--;
		return this;
	}

	@Override
	public String substring(int start, int end) {
		String subString = "";
		for (int i = start; i < end; i++) {
			subString += text[i];
		}
		return subString;
	}

	@Override
	public String substring(int start) {
		String subString = "";
		for (int i = start; i < length; i++) {
			subString += text[i];
		}
		return subString;
	}

	@Override
	public int indexOf(char chr) {
		int pos = -1;
		for (int i = 0; i < length; i++) {
			if(text[i] ==chr){
				pos = i;
				break;
			}
		}
		return pos;
	}

	@Override
	public boolean equals(Object o) {
		boolean res = (this==o);
	if(!res && o instanceof DString){
		DString str = (DString)o;
		res = (length == str.length());
		for (int i = 0; i < length && res; i++) {
			res = (text[i] == str.text[i]);
		}
	}
		return res;
	}

	@Override
	public DString reverse() {
		char[] reverse = new char[length];
		for (int i = 0; i < length ; i++) {
			reverse[i] = text[(length-1)-i];
		}
		text = reverse;
		return this;
	}

	public boolean contains(String str){
		boolean bol = false;
		for (int i = 0; i < length-str.length(); i++) {
			String test = "";
			for (int j = 0; j < str.length(); j++) {
				test += text[i+j];
			}
			System.out.println(test);
			if(str.equals(test)){
				bol=true;
				break;
			}
		}
		return bol;
	}
}