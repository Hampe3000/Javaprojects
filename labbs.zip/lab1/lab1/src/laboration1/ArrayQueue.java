package laboration1;

public class ArrayQueue<T> implements Queue{
    private T[] elements;
    private int size = 0;

    public ArrayQueue(int capacity){
        elements = (T[])(new Object[capacity]);
    }

    @Override
    public void add(Object element) {
        if(size>=elements.length){
            throw new RuntimeException("ERROR");
        }
        elements[size] = (T) element;
        size++;
    }

    @Override
    public Object element() {
        if(size < 0){
            throw new RuntimeException("ERROR");
        }
        return elements[0];
    }

    @Override
    public Object remove() {
        if(size == 0){
            throw new RuntimeException("ERROR");
        }
        T retObj = elements[0];
        for (int i = 0; i < size - 1; i++) {
            elements[i] = elements[i+1];
        }
        size--;
        return retObj;
    }

    @Override
    public boolean isEmpty() {
        if(size == 0){
            return true;
        }
        return false;
    }

    @Override
    public int size() {
        return size;
    }
}
