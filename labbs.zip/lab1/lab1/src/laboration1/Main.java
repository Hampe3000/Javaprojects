package laboration1;

public class Main {

    public static void main(String[] args) {
       ArrayQueue<Integer> qu = new ArrayQueue<>(10);

       qu.add(90);
       qu.add(12);
       qu.add("hej");
       System.out.println(qu.size());
       System.out.println(qu.element());
       System.out.println(qu.remove());
       System.out.println(qu.remove());
       System.out.println(qu.isEmpty());
       System.out.println(qu.remove());
    }
}
