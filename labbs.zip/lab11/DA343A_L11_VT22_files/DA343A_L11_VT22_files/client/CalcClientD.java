package L11.client;

import L11.lab11.Calculation;
import L11.lab11.Expression;

import java.io.*;
import java.net.Socket;

public class CalcClientD implements CalcClient {
    private CalcController controller;
    private String ip;
    private int port;
    private Socket socket;
    private ObjectInputStream ois;
    private ObjectOutputStream oos;


    public CalcClientD(String ip, int port) throws IOException {
        //TODO
        // Samma som i CalcClientB och CalcClientC
        // Starta en tråd (t.ex. inre klass) som lyssnar på svar från servern (readObject())
        // Obs! Typkonvertering krävs!
        this.ip = ip;
        this.port = port;
        socket = new Socket(ip, port);
        System.out.println("socket skapad");
        ois = new ObjectInputStream(socket.getInputStream());
        System.out.println("ois skapad");
        oos = new ObjectOutputStream(socket.getOutputStream());
        System.out.println("oos skapad");
        new Listener().start();
    }

    public void setCalcController(CalcController controller) {
        this.controller = controller;
    }

    public void newCalculation(String expression) throws IOException {
        //TODO
        // Räkneuppgiften ska inte överföras som en string (expression) utan som ett Expression-objekt (L11.lab12.Expression).
        // För att dela upp expression-string kan expression.split(",") användas precis som i CalcClientC
        // Expression-objektet ska sedan skickas med writeObject()
        double num1 = Double.NaN;
        double num2 = Double.NaN;
        char operation = ' ';
        String[] parts = expression.split(",");
        try{
            num1 = Double.parseDouble(parts[0]);
            num2 = Double.parseDouble(parts[1]);
            operation = parts[2].charAt(0);
        }catch (Exception e){
            controller.newResponse("Invalid expression! " + parts[0] + parts[2] + parts[1]);
            return;
        }

        oos.writeObject(new Expression(num1, num2, operation));
        oos.flush();
    }

    private class Listener extends Thread{
        @Override
        public void run() {
            Calculation response;
            try {
                while (true){
                    response = (Calculation) ois.readObject();
                    controller.newResponse(response.toString());
                }
            }catch (Exception e){}
            try{
                socket.close();
            }catch (Exception e){}
            controller.newResponse("Klient kopplar ner");
        }
    }

}