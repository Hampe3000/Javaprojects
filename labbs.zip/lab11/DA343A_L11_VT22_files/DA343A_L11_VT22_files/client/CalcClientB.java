package L11.client;

import java.io.*;
import java.net.Socket;

public class CalcClientB implements CalcClient {
    private CalcController controller;
    private String ip;
    private int port;
    private Socket socket;
    private DataInputStream dis;
    private DataOutputStream dos;

    public CalcClientB(String ip, int port) throws IOException {
        //TODO
        // Koppla upp mot servern (ip och port)
        // Använd Timeout 5000 ms
        // Använd en kombination av DataInputStream och BufferedInputStream för att läsa från sockets InputStream
        // Använd en kombination av DataOutputStream och BufferedOutputStream för att skriva i sockets OutputStream
        // Starta en tråd (t.ex. inre klass) som lyssnar på svar från servern (readUTF())
        this.ip = ip;
        this.port = port;
        socket = new Socket(ip, port);
        socket.setSoTimeout(5000);
        dis = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
        dos = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
        new Listner().start();
    }

    public void setCalcController(CalcController controller) {
        this.controller = controller;
    }

    public void newCalculation(String expression) throws IOException {
        //TODO: Överför en sträng (expression) med writeUTF()
        dos.writeUTF(expression);
        dos.flush();
    }

    private class Listner extends Thread{
        @Override
        public void run() {
            String response;
            try{
                while (true){
                    response = dis.readUTF();
                    controller.newResponse(response);
                }
            }catch (Exception e){}
            try {
                socket.close();
            }catch (Exception e){}
            controller.newResponse("Klien kopplar ner");
        }
    }
}