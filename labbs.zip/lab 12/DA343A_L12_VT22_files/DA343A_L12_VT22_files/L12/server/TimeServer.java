package L12.server;

//TODO
// TimeServer ska ärva Thread och överskugga run()-metoden
// En instans av servern skapas och startas (se main-metod)
// I run-metoden öppnar servern en socket (port 13) och väntar på en klient ( socket.accept() )
// Vid uppkoppling av den klient skapar servern en OutputStream och skickar datumet ( new Date().toString() )
// Sedan väntar servern på den nästa klienten ( socket.accept() )

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class TimeServer extends Thread {
    public void run() {
        try(ServerSocket serverSocket = new ServerSocket(13)){
            while (true){
                try (Socket socket = serverSocket.accept()){
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                    bw.write(new Date().toString());
                    bw.newLine();
                    bw.flush();
                }catch (Exception e){}
            }
        }catch(Exception e){}
    }

    public static void main(String[] args) {
        new TimeServer().start();
    }
}
