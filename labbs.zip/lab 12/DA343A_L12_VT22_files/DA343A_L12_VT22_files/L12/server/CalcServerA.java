package L12.server;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class CalcServerA implements Runnable {
    private Calculator calculator;
    private ServerSocket serverSocket;

    public CalcServerA(Calculator calculator, int port) {
        try {
            this.calculator = calculator;

            //TODO
            // Skapa en ServerSocket som lyssnar på port
            // Starta tråden i det skapade CalcServerA-objektet
            // (Eftersom klassen implementerar Runnable måste först ett Thread-objekt skapas med CalcServerA-objektet som parameter [this])
            ServerSocket serverSocket = new ServerSocket(port);
            new Thread(this).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        System.out.println("Server A startad");
        String[] parts;
        String request, response = "";
        double num1, num2, answer;
        char operation;

        //TODO
        // Servern ska, i en ändlös-slinga, vänta på uppkopplingar (socket.accept())
        // Vid uppkoppling skapas både DataInputStream och DataOutputStream som kopplas till
        //   server-sockets respektive InputStream och OutputStream.
        // Servern läser räkneuppgiften (readUTF()) och delar upp den (split(",")).
        // Resultatet beräknas med hjälp av calculator.calculate(number, number, operation) och skickas tillbaka med writeUTF()
        // Meddelandet ska ha det här formatet ”1+1=2” och du kan använda metoden answerFormat() för att formatera svaret.

        while (true) {
            System.out.println("in loop");
            try(Socket socket = serverSocket.accept()){
                DataInputStream dis = new DataInputStream(socket.getInputStream());
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                request = dis.readUTF();
                parts = request.split(",");
                if(parts.length == 3){
                    try{
                        num1 = Double.parseDouble(parts[0]);
                        num2 = Double.parseDouble(parts[1]);
                        operation = parts[2].charAt(0);
                        answer = calculator.calculate(num1, num2, operation);
                        response = answerFormat(num1, num2, operation, answer);
                    }catch (Exception e){
                        response = e.toString() + "\n" + parts[0] + parts[2] + parts[1];
                    }
                }
                else{
                    response = "Fel antal argument: " + parts.length;
                }
                dos.writeUTF(response);
                dos.flush();
            }catch (IOException e){
                System.err.println(e);
            }
        }

    }
    
    private String answerFormat(double nbr1, double nbr2, char operation, double result){
        return nbr1 + operation + nbr2 + "=" + result;
    }

    public static void main(String[] args) {
        new CalcServerA(new Calculator(), 721);
    }
}