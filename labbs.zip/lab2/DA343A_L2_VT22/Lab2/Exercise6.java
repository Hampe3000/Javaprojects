package laboration2.Lab2;
import java.util.*;

public class Exercise6 {
    private LinkedList<String> list = new LinkedList<String>();

    public void add(String str) {
        list.add(str);
    }

    public void remove(String str) {
        list.remove(str);
    }

    public void print() {
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }

    public void printReverse() {
        for (int i = list.size(); i > -1 ; i--) {
            System.out.println(list.get(i));
        }
    }

    public int size() {
        return list.size();
    }

    public void print6() {
        for (int i = 0; i < list.size(); i++) {
            if(list.get(i).length() > 5){
                System.out.println(list.get(i));
            }
        }
    }

    public int count(char chr) {
        int count = 0;
        for (int i = 0; i < list.size(); i++) {
            if(list.get(i).indexOf(chr) == 0){count++;}
        }
        return count;
    }
}
