package Model;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Date;

public class Message {
    private User sender;
    private String text;
    private ImageIcon image; // todo, kolla så att det är imageIcon vi ska använda
    private String chatID;
    private Date timeSend; //todo, kolla så att typen är korrekt
    private Date timeRecived;


    public Message(User sender, Date timeSend, String text, ImageIcon image, String chatID){
        this.sender = sender;
        this.timeSend = timeSend;
        this.text = text;
        this.image = image;
        this.chatID = chatID;

    }

    public User getSender() {
        return sender;
    }

    public String getText() {
        return text;
    }

    public ImageIcon getImage() {
        return image;
    }

    public Date getTimeSend() {
        return timeSend;
    }

    public Date getTimeRecived() {
        return timeRecived;
    }

    public void setTimeRecived(Date timeRecived) {
        this.timeRecived = timeRecived;
    }

    public String getChatID(){
        return  chatID;
    }

}
