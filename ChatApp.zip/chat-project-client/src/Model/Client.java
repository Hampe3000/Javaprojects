package Model;

import Controller.Controller;
import Model.Request.Request;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Client extends Thread {

    private String IP;
    private int port;
    private Controller controller;

    private Socket socket;
    private ObjectInputStream ois;
    private ObjectOutputStream oos;


    public Client(Controller controller, String IP, int port){
        this.controller = controller;
        this.IP = IP;
        this.port = port;
        try {
            socket = new Socket(IP,port);
            ois = new ObjectInputStream(new BufferedInputStream(socket.getInputStream()));
            oos = new ObjectOutputStream(socket.getOutputStream());
            this.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run(){
        while(true){
            try {
                Object input = ois.readObject();
                controller.response(input);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public void sendRequest(Request request){
        try {
            oos.writeObject(request);
            oos.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
