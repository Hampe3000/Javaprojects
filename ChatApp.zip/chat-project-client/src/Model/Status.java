package Model;

public enum Status {

    online,
    offline,
    do_not_disturb,
    invisible

}
