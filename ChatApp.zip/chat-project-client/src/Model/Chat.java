package Model;

import java.util.ArrayList;

public class Chat {
    private ArrayList<User> participants;
    private ArrayList<Message> messages;
    private int chatID;
    private String nameOfChat;

    public Chat(ArrayList<User> participants, ArrayList<Message> messages, int chatID,String nameOfChat) {
        this.participants = participants;
        this.messages = messages;
        this.chatID = chatID;
        this.nameOfChat = nameOfChat;
    }


    // GETTER AND SETTER
    public void addParticipant(User user){
        participants.add(user);
    }

    public void removeParticipant(User usel){
        participants.remove(usel);
    }

    public void addMessage(Message msg){
        messages.add(msg);
    }

    public void removeMessage(int index){ //todo, int index or maybe Message msg, check what works best with gui
        messages.remove(index);
    }

    public ArrayList<User> getParticipants() {
        return participants;
    }

    public void setParticipants(ArrayList<User> participants) {
        this.participants = participants;
    }

    public ArrayList<Message> getMessages() {
        return messages;
    }

    public int getChatID() {
        return chatID;
    }

    public void setChatID(int chatID) {
        this.chatID = chatID;
    }

    public void setMessages(ArrayList<Message> messages) {
        this.messages = messages;
    }

    public String getNameOfChat() {
        return nameOfChat;
    }

    public void setNameOfChat(String nameOfChat) {
        this.nameOfChat = nameOfChat;
    }
}
