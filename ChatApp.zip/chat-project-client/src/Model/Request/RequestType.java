package Model.Request;

public enum RequestType {

    //todo, server can create a switch case for what is requested from the client

    login,
    register,
    send_message,
    delete_message,
    change_profilePicture,
    create_chat,
    leave_chat,
    add_to_chat,
    update_status,
    remove_contact,
    add_contact
}
