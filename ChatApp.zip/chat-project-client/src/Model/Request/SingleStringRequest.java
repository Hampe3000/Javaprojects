package Model.Request;

public class SingleStringRequest extends Request {
    private String newUsername;

    public SingleStringRequest(RequestType requestType, String newUsername) {
        super(requestType);
        this.newUsername = newUsername;
    }

    public String getNewUsername(){
        return newUsername;
    }
}
