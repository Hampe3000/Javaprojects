package Model.Request;

import Model.User;

public class UserRequest extends Request{
    private User user;

    public UserRequest(RequestType requestType, User usel) {
        super(requestType);
        user = usel;
    }

    public User getUser() {
        return user;
    }
}
