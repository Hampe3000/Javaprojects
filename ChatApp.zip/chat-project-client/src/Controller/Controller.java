package Controller;

import Model.Client;
import Model.Request.DubbleStringRequest;
import Model.Request.Request;
import Model.Request.RequestType;
import Model.User;
import View.Chat.MainFrameChat;
import View.LoginMainFrame;
import View.MainMenu.ContactUser;
import View.MainMenu.MainMenuMainFrame;
import View.MainMenu.OnlineUser;

import java.awt.*;

public class Controller {
    private Client client;
    private User currentUser;
    private LoginMainFrame loginMainFrame;
    private MainMenuMainFrame mainMenuMainFrame;
    private MainFrameChat mainFrameChat;

    public Controller() {
        // Login
     //   LoginMainFrame mainFrame = new LoginMainFrame(this, 800, 600);

        // Main menu
        // MainMenuMainFrame mainFrame = new MainMenuMainFrame(this, 1000, 800);

        // Chat window
        // MainFrameChat mainFrame = new MainFrameChat(this, 800, 600);

        // Demo of main menu
        // MainMenuDemo();

        start();
    }

    private void MainMenuDemo() {
        MainMenuMainFrame mainMenuMainFrame = new MainMenuMainFrame(this, 1000, 800);
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addOnlineUser(new OnlineUser(this, "Name A", true));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addOnlineUser(new OnlineUser(this, "Name B", true));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addOnlineUser(new OnlineUser(this, "Name C", false));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addOnlineUser(new OnlineUser(this, "Name D", false));

        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addContactUser(new ContactUser(this, "Name A", Color.green));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addContactUser(new ContactUser(this, "name B", Color.green));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addContactUser(new ContactUser(this, "Name C", Color.red));
        mainMenuMainFrame.getMainMenuMainPanel().getRightPanel().addContactUser(new ContactUser(this, "Name D", Color.blue));



    }

    public void start(){
        client = new Client(this,"127.0.0.1",1337);
        loginMainFrame = new LoginMainFrame(this, 800, 600);
    }

    public void login(String username, char[] password){
        String strPassword = null;
        for (int i = 0; i < password.length; i++) {
            strPassword += password[i];
        }
        Request request = new DubbleStringRequest(RequestType.login, username, strPassword);
        client.sendRequest(request);
    }

    public void register(String username, char[] password){
        String strPassword = null;
        for (int i = 0; i < password.length; i++) {
            strPassword += password[i];
        }
        Request request = new DubbleStringRequest(RequestType.register, username, strPassword);
        client.sendRequest(request);
    }

    public void response(Object obj){
        if(obj instanceof User){
            currentUser = (User) obj;
            updateAll();
        }
        else if(obj instanceof String){
            loginFailed((String) obj);
        }
    }

    public void loginFailed(String failure){
        if(failure.equals("Wrong password")){
            loginMainFrame.displayLoginError("Wrong password!");
        }

        else if(failure.equals("Non existing user")){
            loginMainFrame.displayLoginError("User does not exist, please create a new user!");
        }

        else{
            System.err.println("Unknown failure");
        }
    }

    public void updateAll(){
        if(loginMainFrame.isActive()) {
            loginMainFrame.dispose();
            //loginMainFrame.setVisible(false);
        }

        mainMenuMainFrame = new MainMenuMainFrame(this, 800, 600);
    }
}
