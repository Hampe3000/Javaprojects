package View;

import Controller.Controller;

import javax.swing.*;

public class LoginMainFrame extends JFrame {

    private LoginMainPanel mainPanel;
    private Controller controller;
    private int width;
    private int height;

    public LoginMainFrame(Controller controller, int width, int height){
        super("Chat system");

        this.controller = controller;
        this.width = width;
        this.height = height;
        this.setSize(width, height);

        mainPanel = new LoginMainPanel(controller, width, height);
        this.setContentPane(mainPanel);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void displayLoginError(String error){
        mainPanel.displayLoginError(error);
    }
}
