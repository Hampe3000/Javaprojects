package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenuMainPanel extends JPanel implements ActionListener{

    private Controller controller;
    private int width;
    private int height;

    private RigthPanel rightPanel;
    private LeftPanel leftPanel;
    private JMenuBar menuBar;

    public MainMenuMainPanel(Controller controller, int width, int height){
        super(new BorderLayout());
        this.controller = controller;
        this.width = width;
        this.height = height;
        this.setSize(width, height);

        setUp();
    }

    private void setUp() {
        menuBar = menuBarSetup();
        this.add(menuBar, BorderLayout.NORTH);

        rightPanel = new RigthPanel(controller);
        leftPanel = new LeftPanel(controller, width, height);
        JPanel chatsAndUsers = new JPanel(new GridLayout(0, 2));

        chatsAndUsers.add(leftPanel);
        chatsAndUsers.add(rightPanel);

        this.add(chatsAndUsers, BorderLayout.CENTER);
    }

    /**
     * This method creates and sets up a JMenuBar that is returned.
     * @return jMenuBar : JMenuBar, this is the JMenuBar that contains the JMenu items that are set up in this method.
     */
    private JMenuBar menuBarSetup() {
        // Create the JMenuBar and the menus it contains
        JMenuBar jMenuBar = new JMenuBar();
        JMenu optionsMenu = new JMenu("Options");
        JMenu statusMenu = new JMenu("Status");
        JMenu logoutMenu = new JMenu("Logout");

        // optionsMenu buttons
        JMenuItem optionA = new JMenuItem("Option A");
        JMenuItem optionB = new JMenuItem("Option B");
        JMenuItem optionC = new JMenuItem("Option C");

        optionA.addActionListener(this);
        optionB.addActionListener(this);
        optionC.addActionListener(this);

        optionsMenu.add(optionA);
        optionsMenu.add(optionB);
        optionsMenu.add(optionC);

        // statusMenu buttons
        JMenuItem onlineOptionA = new JMenuItem("Online");
        JMenuItem onlineOptionB = new JMenuItem("Mer online");
        JMenuItem onlineOptionC = new JMenuItem("Do not disturb");

        onlineOptionA.addActionListener(this);
        onlineOptionB.addActionListener(this);
        onlineOptionC.addActionListener(this);

        statusMenu.add(onlineOptionA);
        statusMenu.add(onlineOptionB);
        statusMenu.add(onlineOptionC);

        // logout Button
        JMenuItem logoutButton = new JMenuItem("Logout");
        logoutButton.addActionListener(this);
        logoutMenu.add(logoutButton);

        // Add all menus to the menu bar
        jMenuBar.add(optionsMenu);
        jMenuBar.add(statusMenu);
        jMenuBar.add(logoutMenu);

        return jMenuBar;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JMenuItem thing = (JMenuItem) e.getSource();
        System.out.println(thing.getText());
    }

    public RigthPanel getRightPanel() {
        return rightPanel;
    }

    public void setRightPanel(RigthPanel rightPanel) {
        this.rightPanel = rightPanel;
    }

    public LeftPanel getLeftPanel() {
        return leftPanel;
    }

    public void setLeftPanel(LeftPanel leftPanel) {
        this.leftPanel = leftPanel;
    }
}
