package View.MainMenu;

import javax.swing.*;
import Controller.*;

public class MainMenuMainFrame extends JFrame {

    private int width;
    private int height;
    private Controller controller;

    private MainMenuMainPanel mainMenuMainPanel;

    public MainMenuMainFrame(Controller controller, int width, int height) {
        super("Ingvar02 Chat Service"); // Todo: Change title.

        this.controller = controller;
        this.height = height;
        this.width = width;

        this.setResizable(true);
        this.setSize(width, height);
        this.mainMenuMainPanel = new MainMenuMainPanel(controller, width, height);
        this.setContentPane(mainMenuMainPanel);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public MainMenuMainPanel getMainMenuMainPanel() {
        return mainMenuMainPanel;
    }

    public void setMainMenuMainPanel(MainMenuMainPanel mainMenuMainPanel) {
        this.mainMenuMainPanel = mainMenuMainPanel;
    }
}
