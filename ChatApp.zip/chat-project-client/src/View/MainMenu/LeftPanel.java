package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

public class LeftPanel extends JPanel {

    private Controller controller;
    private int width;
    private int height;

    // Object lists

    private JScrollPane jScrollPane;
    private JList<Object> chatsList;

    public LeftPanel(Controller controller, int width, int height){
        super(new BorderLayout());
        this.controller = controller;
        this.width = width;
        this.height = height;

        setup();
    }

    private void setup() {

        // Chats object list
        chatsList = new JList<Object>();
        chatsList.setLocation(0, height / 8);
        chatsList.setSize(width / 2, height - (height / 4));

        JScrollPane chatsListScroll = new JScrollPane();
        chatsListScroll.setViewportView(chatsList);
        chatsListScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        chatsListScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        // chatsList.setLayoutOrientation(JList.VERTICAL);
        // Todo: Add action listener
        this.add(chatsListScroll);

    }
}
