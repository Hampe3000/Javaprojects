package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

public class RigthPanel extends JPanel {

    private Controller controller;

    private JList<Object> onlineList;
    private JList<Object> contactList;

    private JPanel onlineTest;
    private JPanel contactTest;

    public RigthPanel(Controller controller) {
        super(new BorderLayout());
        this.controller = controller;

        setup();
    }

    private void setup() {
        onlineList = new JList<>();
        contactList = new JList<>();

        JScrollPane onlineScrollPane = new JScrollPane();
        JScrollPane contactScrollPane = new JScrollPane();

        onlineScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        contactScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        onlineScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        contactScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        onlineTest = new JPanel(new GridLayout(0, 1));
        contactTest = new JPanel(new GridLayout(0, 1));

        onlineScrollPane.setViewportView(onlineTest);
        contactScrollPane.setViewportView(contactTest);

        JSplitPane contactsAndOnline = new JSplitPane(JSplitPane.VERTICAL_SPLIT, contactScrollPane, onlineScrollPane);
        contactsAndOnline.setDividerLocation(300);

        this.add(contactsAndOnline);
    }

    public void addOnlineUser(OnlineUser newOnlineUser) {
        onlineTest.add(newOnlineUser);
    }

    public void addContactUser(ContactUser contactUser){
        contactTest.add(contactUser);
    }

}
