package View.Chat;

import Controller.Controller;
import View.MainMenu.MainMenuMainPanel;

import javax.swing.*;

public class MainFrameChat extends JFrame {

    private Controller controller;
    private int width;
    private int height;
    private MainPanelChat mainPanelChat;

    public MainFrameChat(Controller controller, int width, int height){ //todo: lägg till controller
        super("titel"); //todo: lägg till titel för chatten

        this.controller = controller;
        this.height = height;
        this.width = width;

        this.setResizable(true);
        this.setSize(width, height);
        mainPanelChat = new MainPanelChat(this.controller, this.width, this.height);
        this.setContentPane(mainPanelChat);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Todo: Delete later
    }
}
