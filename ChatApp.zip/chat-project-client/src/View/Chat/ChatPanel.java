package View.Chat;

import Controller.Controller;

import javax.swing.*;
/*
public class ChatPanel extends JPanel {

    private Controller controller;
    private int width;
    private int height;

    private JPanel chatField;

    public ChatPanel(Controller controller, int width, int height){
        this.controller = controller;
        this.width = width;
        this.height = height;
        this.setSize(width,height);

        setUp();
    }

    public void setUp(){
        chatField = new JPanel();
        chatField.setLocation(0,height/2);
        chatField.setSize(width/2, height/2);
        this.add(chatField);
    }

}

 */
