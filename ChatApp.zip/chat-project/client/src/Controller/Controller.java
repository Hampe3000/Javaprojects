package Controller;

import Model.client.*;
import Model.client.Request.*;
import View.MainMenu.*;
import View.Login.*;
import View.Chat.*;
import View.Register.RegisterFrame;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * This class is the controller for the client side application.
 *
 * @authors Hedda Eriksson, Hampus Oxenholt, Eddie Peters, Ingvar Pétursson, Alicia Sondh & Robin Zhang
 */
public class Controller {
    private Client client;
    private User currentUser;
    private Message message;
    private LoginMainFrame loginMainFrame;
    private MainMenuMainFrame mainMenuMainFrame;
    private ArrayList<MainFrameChat> mainFrameChats;
    private RegisterFrame registerFrame;

    /**
     * This is the constructor for the class. It displays a new LoginFrame and initializes a list of ChatFrames.
     */
    public Controller() {
        loginMainFrame = new LoginMainFrame(this, 800, 600);
        mainFrameChats = new ArrayList<MainFrameChat>();
    }

    /**
     * This method creates a new Client responsible for communicating with the server.
     */
    public void start() {
        client = new Client(this, "localhost", 1337);
    }

    /**
     * This method is called from the loginFrame when the login button is pressed. It then calls the start method, converts the char[]
     * to a String and sends a new request to the client.
     *
     * @param username is the Username that the user is trying to login with.
     * @param password is the password the user is trying to login with (not actually used by the server at the moment).
     */
    public void login(String username, char[] password) {
        start();
        String strPassword = null;
        for (int i = 0; i < password.length; i++) {
            strPassword += password[i];
        }
        Request request = new DoubleStringRequest(RequestType.login, username, strPassword);
        client.sendRequest(request);
    }

    /**
     * This method is called when the user presses the register button on the loginFrame.
     * The method then disposes the loginFrame and displays a new RegisterFrame.
     */
    public void loadContacts() {
        File file = new File("files/ContactList/list.txt");

        if (file.exists()) {
            try {
                ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
                ArrayList<User> userList = (ArrayList<User>) ois.readObject();
                currentUser.setContacts(userList);
            } catch (Exception e) {
                System.out.println("Controller.java: loadContacts: " + e);
            }
        }
    }

    public void register() {
        loginMainFrame.dispose();
        registerFrame = new RegisterFrame(this, 400, 600);
    }

    /**
     * This method is called from the registerFrame. It converts the char[] to a String and then creates a new User, then it uses the
     * new User to create a new Request and sends it to the client.
     *
     * @param userName is the userName for the new User.
     * @param password is a char[] of the password for the new User.
     * @param image    is the profilePicture for the new User.
     */
    public void registerNewUser(String userName, char[] password, String image) {
        String strPassword = "";
        for (int i = 0; i < password.length; i++) {
            strPassword += password[i];
        }
        User user = new User(userName, image, strPassword, Status.online, "Online", new ArrayList<User>(), new ArrayList<Chat>(), new ArrayList<User>());
        Request request = new UserRequest(RequestType.register, user);
        start();
        client.sendRequest(request);
    }

    /**
     * This method is called from the client whenever something arrives from the server. Depending on the type of object a
     * different sequence of code will be executed. If the object is an instance of User, and it is the first User object
     * received the currentUser will be set to the obj. If this isn't the first user received the update other user info method is
     * called both internally and in the currentUser. If the object is an instance of chat the updateChats methods are called  both
     * internally and in the currentUser object. If the object is null a login error is displayed in the loginFrame. Then all frames
     * that aren't null are updated.
     *
     * @param obj is the object received from the server.
     */
    public void response(Object obj) {
        if (obj instanceof User) {

            if (currentUser == null) {
                currentUser = (User) obj;
                if (loginMainFrame != null) {
                    loginMainFrame.dispose();
                }
                if (registerFrame != null) {
                    registerFrame.dispose();
                }
                mainMenuMainFrame = new MainMenuMainFrame(this, 800, 600, currentUser.getUserName());
                byte[] picData = currentUser.getProfilePic();
                Image image = new ImageIcon(picData).getImage();
                mainMenuMainFrame.setIconImage(image);
                setupOtherUserInfo();
                loadContacts();
                String[] chats = new String[currentUser.getChats().size()];
                System.out.println(chats.length);
                for (int i = 0; i < chats.length; i++) {
                    chats[i] = currentUser.getChats().get(i).toString();
                    System.out.println(chats[i]);
                }
                mainMenuMainFrame.updateChats(chats);
            } else {
                currentUser.updateOtherUsersStatus((User) obj);
            }
            updateOtherUserInfo();

        } else if (obj instanceof String) {
            loginFailed((String) obj);
        } else if (obj instanceof Chat) {
            currentUser.updateChats((Chat) obj);
            updateChat((Chat) obj);

        } else if (obj == null) {
            loginMainFrame.getMainPanel().displayLoginError("error!");
        }
        if (mainMenuMainFrame != null) {
            mainMenuMainFrame.updatePanels();
        }
        if (mainFrameChats != null) {
            for (int i = 0; i < mainFrameChats.size(); i++) {
                mainFrameChats.get(i).updatePanels();
            }
        }
    }

    /**
     * This method isn't finished it may be implemented in a later update of the application.
     *
     * @param failure this would be a String specifying  the reason why the login failed.
     */
    public void loginFailed(String failure) {
        if (failure.equals("Wrong password")) {
            loginMainFrame.displayLoginError("Wrong password!");
        } else if (failure.equals("Non existing user")) {
            loginMainFrame.displayLoginError("User does not exist, please create a new user!");
        } else if (failure.equals("Username already taken")) {
            loginMainFrame.displayLoginError("Sadly this username is already in use by someone else :(");
        } else {
            System.err.println("Unknown failure");
        }
    }

    /**
     * This method updates the right panel in main menu with the latest information about other users.
     * It does this by creating two arrays of panel objects one for every user in the currentUsers contactList and
     * one for the currentUsers onlineList. It then sends these arrays to mainMenuMainFrame which refreshes its right panel.
     */
    public void updateOtherUserInfo() {
        ArrayList<ContactUser> contactList = new ArrayList<ContactUser>();
        ArrayList<User> myContacts = currentUser.getContacts();
        for (int i = 0; i < myContacts.size(); i++) {
            String name = myContacts.get(i).getUserName();
            Color color = null;
            switch (myContacts.get(i).getCurrentStatus()) {
                case online:
                    color = Color.GREEN;
                    break;
                case offline:
                    color = Color.GRAY;
                    break;
            }
            contactList.add(new ContactUser(this, name, color));
        }
        ArrayList<User> theOthers = currentUser.getUsersOnline();
        ArrayList<OnlineUser> onlineUsers = new ArrayList<OnlineUser>();
        for (int i = 0; i < theOthers.size(); i++) {
            String name = theOthers.get(i).getUserName();
            if (!name.equals(currentUser.getUserName())) {
                onlineUsers.add(new OnlineUser(this, name, true));
            }
        }
        mainMenuMainFrame.updateUsers(contactList, onlineUsers);
    }

    /**
     * This method updates the left panel in main menu and refreshes any MainFrameChat currently displaying the specified chat.
     * It does this by creating an array of MessageDialogs and an array of Participant getting the data for this from the chat
     * received as a parameter. It then sends these arrays to any MainFrameChat currently displaying this chat. The method then
     * loops through all the currentUsers chats and creates a String array containing information oof when the last message was
     * sent to the chat, this array is then sent to the mainMenuMainFrame.
     *
     * @param chat the chat with updates.
     */
    public void updateChat(Chat chat) {

        MessageDialog[] messages = new MessageDialog[chat.getMessages().size()];
        ArrayList<Message> theMessages = chat.getMessages();

        for (int i = 0; i < theMessages.size(); i++) {
            byte[] picData = theMessages.get(i).getImage();

            Image image = null;
            if (picData != null) {
                image = new ImageIcon(picData).getImage();
            }

            messages[i] = new MessageDialog(this, theMessages.get(i).getSender().getUserName(), theMessages.get(i).getText(), theMessages.get(i).getTimeSend().toString(), image);
        }

        Participant[] participants = new Participant[chat.getParticipants().size()];
        ArrayList<User> users = chat.getParticipants();
        boolean isOnline = true;

        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getCurrentStatus() != Status.online) {
                isOnline = false;
            }
            byte[] picData = users.get(i).getProfilePic();
            Image image = new ImageIcon(picData).getImage();
            participants[i] = new Participant(image, users.get(i).getUserName(), isOnline);
        }

        for (int i = 0; i < mainFrameChats.size(); i++) {
            mainFrameChats.get(i).UpdateChats(chat.getChatID(), messages, participants);
        }

        String[] chats = new String[currentUser.getChats().size()];
        for (int i = 0; i < currentUser.getChats().size(); i++) {
            System.out.println("iteration " + i + "in client controller updateChat");
            int last = currentUser.getChats().get(i).getMessages().size() - 1;
            DateFormat date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String dateStr = date.format(currentUser.getChats().get(i).getMessages().get(last).getTimeSend());

            chats[i] = currentUser.getChats().get(i).getNameOfChat() + ", " +
                    currentUser.getChats().get(i).getMessages().get(last).getSender().getUserName() + ", Time sent: " +
                    dateStr;
        }
        mainMenuMainFrame.updateChats(chats);
    }

    /**
     * This method is called from mainMenuMainframe when the user presses the OpenChat button.
     * An array of Strings each String being the name of a chat, this array is then sent to the mainMenuMainFrame which
     * returns one of these Strings telling us which chat should be opened. The method then checks which chats are already
     * displayed. If this chat is already being displayed nothing happens, otherwise a new MainFrameChat is created and added
     * to the list mainFrameChats. When a MainFrameChat is closed it is removed from the list.
     */
    public void displayChat() {

        String[] chats = new String[currentUser.getChats().size()];
        for (int i = 0; i < chats.length; i++) {
            chats[i] = currentUser.getChats().get(i).getNameOfChat();
        }
        String theChat = mainMenuMainFrame.whichChat(chats);

        int index = -1;
        for (int i = 0; i < chats.length; i++) {
            if (chats[i].equals(theChat)) {
                index = i;
                break;
            }
        }
        System.out.println("Controller.java: Index: " + index);
        if (index >= 0) {
            boolean alreadyExists = false;
            for (int i = 0; i < mainFrameChats.size(); i++) {
                if (mainFrameChats.get(i).getID() == currentUser.getChats().get(index).getChatID()) {
                    alreadyExists = true;
                    break;
                }
            }
            System.out.println("Controller.java: Boolean: " + alreadyExists);
            if (!alreadyExists) {
                int id = currentUser.getChats().get(index).getChatID();
                String chatName = currentUser.getChats().get(index).getNameOfChat();
                MainFrameChat newChat = new MainFrameChat(this, 800, 600, id, chatName);
                newChat.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        mainFrameChats.remove(newChat);
                    }
                });
                mainFrameChats.add(newChat);
                updateChat(currentUser.getChats().get(index));
            }
        }
    }

    /**
     * This method is used when some part of the application wants to now if a userName is the currentUsers userName.
     *
     * @param sender is a String containing a userName.
     * @return true if the String contains the same characters as the currentUsers userName else it returns false.
     */
    public boolean messageDialogUpdate(String sender) {
        boolean isMyMessage = false;
        if (currentUser.getUserName().equals(sender)) {
            isMyMessage = true;
        }
        return isMyMessage;
    }

    /**
     * This method is called when the user clicks the createChat button. It then creates a new ArrayList of Users and
     * adds the current user to that list it then create a new Message. The method then creates a new Chat and uses this chat
     * to create a new request and calls the client with the new request.
     *
     * @param chatName is the name for the new Chat.
     */
    public void createNewChat(String chatName) {
        ArrayList<User> members = new ArrayList<User>();
        members.add(currentUser);

        ArrayList<Message> messages = new ArrayList<Message>();
        messages.add(new Message(currentUser, new Date(), "Chat created!", null, -1));
        Chat chatToAdd = new Chat(members, messages, chatName);
        Request request = new ChatRequest(RequestType.create_chat, chatToAdd);
        client.sendRequest(request);
    }

    /**
     * This method is called when a user presses the sendMessage button in a MainFrameChat. The method calls the MainFrameChats
     * clearTextArea method. Then it creates a new Message object using the other parameters for this method.
     * The message is then used to create a new Request which is sent to the client.
     *
     * @param source is the MainFrameChat were the button was pressed.
     * @param txtMsg is the text part of the message.
     * @param imgMsg is the picture for the message.
     * @param id     is the id of the chat that should receive the message.
     */
    public void sendMessage(MainFrameChat source, String txtMsg, String imgMsg, int id) {
        source.clearTextArea();
        Message message = new Message(currentUser, new Date(), txtMsg, imgMsg, id);
        Request request = new MessageRequest(RequestType.send_message, message);
        client.sendRequest(request);
    }

    /**
     * This method is called when we receive the first user to update the status of everyone in the currentUsers contactList.
     */
    private void setupOtherUserInfo() {
        for (int i = 0; i < currentUser.getContacts().size(); i++) {
            boolean isOnline = false;
            for (int j = 0; j < currentUser.getUsersOnline().size(); j++) {
                if (currentUser.getContacts().get(i).getUserName().equals(currentUser.getUsersOnline().get(j).getUserName())) {
                    isOnline = true;
                    currentUser.getUsersOnline().remove(j);
                    currentUser.getContacts().get(i).setCurrentStatus(Status.online);
                    currentUser.getContacts().get(i).setStatusName("Online");
                    break;
                }
            }
            if (!isOnline) {
                currentUser.getContacts().get(i).setCurrentStatus(Status.offline);
                currentUser.getContacts().get(i).setStatusName("Offline :(");
            }
        }
    }

    /**
     * This method is called when the user presses the add button on a user in the onlineUsers part of the right panel in
     * mainMenu. The method does this by comparing the received String to the userName of every User in the currentUsers onlineList.
     * When it finds the correct User it adds it to the currentUsersContactList and removes it from the onlineList.
     * Then the method calls the updateOtherUserInfo method and tells the mainMenu to update its panels.
     *
     * @param name the userName of the User to be added to the contactList.
     */
    public void addNewContact(String name) {
        for (int i = 0; i < currentUser.getUsersOnline().size(); i++) {
            if (currentUser.getUsersOnline().get(i).getUserName().equals(name)) {
                currentUser.addContact(currentUser.getUsersOnline().get(i));
                currentUser.getUsersOnline().remove(i);
                break;
            }
        }
        updateOtherUserInfo();
        mainMenuMainFrame.updatePanels();
    }

    /**
     * This method might be implemented in a later update of the application.
     *
     * @param name the userName of the User to be removed from the contactList.
     */
    public void disintegrateContact(String name) {
        //todo later maybe.
    }

    /**
     * This method is called when the logout button is pressed on the mainMenu. The method saves the currentUsers contactList
     * to a file, creates a new Request and send it to the client, the method then closes all open frames and clears the
     * mainframeChatsList.
     */
    public void logout() {
        try {
            ObjectOutputStream ost = new ObjectOutputStream(new FileOutputStream("files/ContactList/list.txt"));
            ost.writeObject(currentUser.getContacts());
            ost.flush();
            ost.close();
        } catch (Exception e) {
            System.err.println("Client.Controller.java : logout Error" + e);
        }
        client.sendRequest(new UserRequest(RequestType.log_out, currentUser));
        if (mainMenuMainFrame != null) {
            mainMenuMainFrame.dispose();
        }
        for (int i = 0; i < mainFrameChats.size(); i++) {
            mainFrameChats.get(i).dispose();
        }
        mainFrameChats.clear();
    }

    /**
     * This method is called when the user presses the add to chat button on a MainFrameChat. The method then creates a String array
     * with the userNames of all the Users in the currentUsers contactList andOnlineList, this array is then sent to the Mainframe chat
     * which returns one of these names which is then matched to a User which is added to the chats participant List. The chat is then
     * used to create a new request which is sent to the client.
     *
     * @param source the MainFrameChat were the button was pressed.
     */
    public void addParticipant(MainFrameChat source) {
        String[] myFriends = new String[currentUser.getContacts().size() + currentUser.getUsersOnline().size()];
        for (int i = 0; i < currentUser.getContacts().size(); i++) {
            myFriends[i] = currentUser.getContacts().get(i).getUserName();
        }
        for (int i = 0; i < currentUser.getUsersOnline().size(); i++) {
            myFriends[currentUser.getContacts().size() + i] = currentUser.getUsersOnline().get(i).getUserName();
        }
        String theFriend = source.addToIngvar02ServiceChat(myFriends);
        Chat theChat = null;
        for (int i = 0; i < currentUser.getChats().size(); i++) {
            if (source.getID() == currentUser.getChats().get(i).getChatID()) {
                theChat = currentUser.getChats().get(i);
                break;
            }
        }
        boolean found = false;
        for (int i = 0; i < currentUser.getContacts().size(); i++) {
            if (theFriend.equals(currentUser.getContacts().get(i).getUserName())) {
                theChat.addParticipant(currentUser.getContacts().get(i));
                found = true;
                break;
            }
        }
        if (!found) {
            for (int i = 0; i < currentUser.getUsersOnline().size(); i++) {
                if (theFriend.equals(currentUser.getUsersOnline().get(i).getUserName())) {
                    theChat.addParticipant(currentUser.getUsersOnline().get(i));
                    break;
                }
            }
        }
        client.sendRequest(new ChatRequest(RequestType.add_to_chat, theChat));
    }

    /**
     * This method is currently unfinished it might de fixed in a later update of the application.
     *
     * @param source the MainFrameChat were the button was pressed.
     */
    public void leaveChat(MainFrameChat source) {
        Chat theChat = null;
        for (int i = 0; i < currentUser.getChats().size(); i++) {
            if (source.getID() == currentUser.getChats().get(i).getChatID()) {
                theChat = currentUser.getChats().get(i);
                currentUser.getChats().remove(i);
                break;
            }
        }
        theChat.removeParticipant(currentUser);

        client.sendRequest(new ChatRequest(RequestType.leave_chat, theChat));
        updateOtherUserInfo();
    }

}
