package Controller;

/**
 * This is the Main used to launch the client side application
 * @author Alicia Sondh
 */
public class Main {

    public static void main(String[] args) {
       // Server server = new Server(1337);
        Controller controller = new Controller();
    }

}

