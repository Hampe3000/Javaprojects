package Controller;

import Controller.Controller;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * This is a test class used by the client side team to test a few features.
 * @author Hampus Oxenholt, Eddie Peters & Alicia Sondh
 */
public class Server extends Thread{

    private int port;
    private ServerSocket serverSocket;

    
    public Server(int port){
        this.port = port;
        try{
            serverSocket = new ServerSocket(port);
            this.start();
        } catch (Exception e){}
    }

    public void run() {
        System.out.println("Controller.Server started");
        while (true) {
            try{
                Socket socka = serverSocket.accept();
                new ClientHandler(socka).start();

            }catch(Exception e){}
        }
    }

    private class ClientHandler extends Thread{
        private Socket socket;
        private ObjectInputStream inputStream;

        public ClientHandler(Socket socket){
            this.socket = socket;
            try{
                inputStream = new ObjectInputStream(socket.getInputStream());
            }catch(Exception ex){}
        }

        public void run(){
            System.out.println("clienthandler staretd");
            Object obj = null;
            while (true){
                try {
                    obj = inputStream.readObject();
                    if(obj != null){
                        System.out.println("Received something");
                    }
                    obj = null;
                }catch(Exception e){}

            }
        }
    }

}
