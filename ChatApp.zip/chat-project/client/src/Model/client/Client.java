package Model.client;

import Controller.Controller;
import Model.client.Request.Request;

import java.io.*;
import java.net.Socket;

/**
 * This class is a thread and handels all the connection to the server
 */
public class Client extends Thread {

    private String IP;
    private int port;
    private Controller controller;

    private Socket socket;
    private ObjectInputStream ois;
    private ObjectOutputStream oos;


    /**
     * The constructor
     * @param controller the controller that is used
     * @param IP the IP-address server and client are connected via
     * @param port the port for connection
     */
    public Client(Controller controller, String IP, int port){
        this.controller = controller;
        this.IP = IP;
        this.port = port;
        try {
            socket = new Socket(IP,port);
            oos = new ObjectOutputStream(socket.getOutputStream());
            oos.flush();
            ois = new ObjectInputStream(new BufferedInputStream(socket.getInputStream()));
            this.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called every time the client received response from the server and then
     * the response is sent to controller where it is handel depends on what response type it is.
     */
    public void run(){
        while(true){
            try {
                Object input = ois.readObject();
                controller.response(input);
            }
            catch(StreamCorruptedException ex) {
               // System.out.println("Client.java: Error: " + ex);
            }
            catch (IOException e) {

                try {
                   // System.out.println("Client.java: Shut down.");
                    ois.close();
                    oos.close();
                    System.exit(0);
                }
                catch(Exception ex) {
                  //  System.out.println("Client.java: Error: " + ex);
                }
            }
            catch (Exception e) {
              //  System.out.println("Tar vi emot objekt?" + e);
            }
        }
    }

    /**
     * This method is called every time the client wants to send a request to the server
     * @param request what request type that is sent
     */
    public void sendRequest(Request request){
        try {
            oos.writeObject(request);
            oos.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}