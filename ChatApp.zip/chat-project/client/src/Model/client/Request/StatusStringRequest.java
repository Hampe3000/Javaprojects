package Model.client.Request;

import Model.client.Status;

/**
 * This is an extension of the general Request class. It's never used as it handled features we later dropped.
 * @author Hampus Oxenholt, Eddie Peters & Alicia Sondh
 */
public class StatusStringRequest extends Request {
    private String newUsername;
    private Status status;

    /**
     * This is the constructor it calls the superClass constructor and set the data from the parameters.
     * @param requestType is what kind of request this is.
     * @param newUsername is a String containing the new name of a status or a new userName
     * @param status the Status of the user.
     */
    public StatusStringRequest(RequestType requestType, String newUsername, Status status) {
        super(requestType);
        this.newUsername = newUsername;
        this.status = status;
    }

    //getter (there should be two)
    public String getNewUsername(){
        return newUsername;
    }
}
