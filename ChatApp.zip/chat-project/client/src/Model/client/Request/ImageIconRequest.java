package Model.client.Request;

import javax.swing.*;

/**
 * This is an extension of the general Request class. It's never used as we changed how images are handled.
 * @author Hampus Oxenholt, Eddie Peters & Alicia Sondh
 */
public class ImageIconRequest extends Request {
    private ImageIcon newProfilePic;

    /**
     * This is the constructor it calls the superClass constructor and then sets the instance variable to the value in the parameter.
     * @param requestType is what kind of request this is.
     * @param newProfilePic is an ImageIcon to be sent to the server.
     */
    public ImageIconRequest(RequestType requestType, ImageIcon newProfilePic) {
        super(requestType);
        this.newProfilePic = newProfilePic;
    }

    //getter
    public ImageIcon getNewProfilePic(){
        return newProfilePic;
    }
}
