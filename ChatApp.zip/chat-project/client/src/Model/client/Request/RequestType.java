package Model.client.Request;

/**
 * This is an enum used to tell the server what to do with a received object.
 * @author Hampus Oxenholt, Eddie Peters & Alicia Sondh
 */
public enum RequestType {
    login,
    register,
    send_message,
    create_chat,
    leave_chat,
    add_to_chat,
    update_status,
    log_out
}
