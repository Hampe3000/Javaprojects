package Model.client.Request;

import Model.client.Chat;

/**
 * This is an extension of the general Request class. It's used when the client needs to send a chat to the server.
 * @author Hampus Oxenholt, Eddie Peters & Alicia Sondh
 */
public class ChatRequest extends Request {
    private Chat chat;

    /**
     * This is the constructor it calls the superClass constructor and the sets the chat.
     * @param requestType what kind of request this is.
     * @param chat the chat that the server Should receive.
     */
    public ChatRequest(RequestType requestType, Chat chat){
        super(requestType);
        this.chat = chat;
    }

    //getter
    public Chat getChat(){return chat;}
}
