package Model.client.Request;

import java.io.Serializable;

/**
 * This class is used as a base class for communication from the client to the server it is abstract and implements Serializable.
 * @author Hampus Oxenholt, Eddie Peters & Alicia Sondh
 */
public abstract class Request implements Serializable {
    private RequestType requestType;

    /**
     * This is the constructor for the class it is always called from a subclass constructor.
     * @param requestType the type of request this object will be.
     */
    public Request(RequestType requestType){
        this.requestType = requestType;
    }

    //getter
    public RequestType getRequestType(){
        return requestType;
    }
}
