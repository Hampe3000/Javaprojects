package Model.client.Request;

/**
 * This is an extension of the general Request class. It's only used when the client wants to log In.
 * @author Hampus Oxenholt, Eddie Peters & Alicia Sondh
 */
public class DoubleStringRequest extends Request {
    private String username;
    private String password;

    /**
     * This is the constructor it calls the superClass constructor and set the data from the parameters.
     * @param requestType is what kind of request this is.
     * @param username is the userName of the user trying to log on.
     * @param password is the password for the user trying to log on. (At the moment it doesn't serve any purpose as
     * the server doesn't check passwords)
     */
    public DoubleStringRequest(RequestType requestType, String username, String password) {
        super(requestType);
        this.username = username;
        this.password = password;
    }

    //getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
