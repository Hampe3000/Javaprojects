package Model.client;


import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * This class handels pictures to be sent in messages and profile pictures in users.
 *
 * @authors Hedda Eriksson, Hampus Oxenholt, Eddie Peters, Ingvar Pétursson, Alicia Sondh & Robin Zhang
 */
public class ImageHandler implements Serializable {
    private byte[] data;

    /**
     * This is the constructor that creates a path via a file where the picture will be saved
     *
     * @param path where the image is saved
     */
    public ImageHandler(String path) {
        this.data = null;

        if (path != null) {
            File file = new File(path);

            if (file.exists()) {
                Path filePath = Paths.get(path);

                try {
                    data = Files.readAllBytes(filePath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Getter
    public byte[] getData() {
        return data;
    }
}
