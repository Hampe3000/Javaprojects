package Model.client;

// Enum for status of every user
public enum Status {

    online,
    offline

}
