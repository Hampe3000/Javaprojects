package Model.client;


import java.io.Serializable;
import java.util.Date;

/**
 * This class is called every time a message is created
 * @authors Hedda Eriksson, Hampus Oxenholt, Eddie Peters, Ingvar Pétursson, Alicia Sondh & Robin Zhang
 */
public class Message implements Serializable{
    private User sender;
    private String text;
    private int chatID;
    private Date timeSend;
    private Date timeRecived;
    private ImageHandler imgHandler;


    /**
     * The constructor contains everything that a message contains
     * @param sender a user who sent the message
     * @param timeSend time when message was sent
     * @param text text message that is written by user
     * @param image image that is chosen by user
     * @param chatID controls that message goes to the right chat
     */
    public Message(User sender, Date timeSend, String text, String image, int chatID){
        this.sender = sender;
        this.timeSend = timeSend;
        this.text = text;
        imgHandler = new ImageHandler(image);
        this.chatID = chatID;

    }

    //getters & setters
    public User getSender() {
        return sender;
    }

    public String getText() {
        return text;
    }

    public byte[] getImage() {
        return imgHandler.getData();
    }

    public Date getTimeSend() {
        return timeSend;
    }

    public Date getTimeRecived() {
        return timeRecived;
    }

    public void setTimeRecived(Date timeRecived) {
        this.timeRecived = timeRecived;
    }

    public int getChatID(){
        return  chatID;
    }

}
