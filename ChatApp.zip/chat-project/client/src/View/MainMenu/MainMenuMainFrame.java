package View.MainMenu;

import javax.swing.*;
import Controller.*;

import java.util.ArrayList;

/**
 * This Class is responsible for creating the mainFrame of the mainMenu. It is also responsible for updating the userList, chatsList
 */
public class MainMenuMainFrame extends JFrame {

    private int width;
    private int height;
    private Controller controller;

    private MainMenuMainPanel mainMenuMainPanel;

     /* This constructor takes the parameters needed to create a new mainMenuMainPanel
     * @param controller - Controller
     * @param width - sets the width of the panel
     * @param height - sets the height of the panel
     */
    public MainMenuMainFrame(Controller controller, int width, int height, String title) {
        super(title);

        this.controller = controller;
        this.height = height;
        this.width = width;

        this.setResizable(true);
        this.setSize(width, height);
        this.mainMenuMainPanel = new MainMenuMainPanel(controller, width, height);
        this.setContentPane(mainMenuMainPanel);
        this.setVisible(true);
        this.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

    }

    public MainMenuMainPanel getMainMenuMainPanel() {
        return mainMenuMainPanel;
    }

    public void setMainMenuMainPanel(MainMenuMainPanel mainMenuMainPanel) {
        this.mainMenuMainPanel = mainMenuMainPanel;
    }

    /**
     * This method updates the contact and onlineUsers lists by calling the method updateUsers in mainMenuMainPanel
     * @param contacts - an ArrayList containing ContactUser objects
     * @param others   - an ArrayList containing OnlineUser objects
     */
    public void updateUsers(ArrayList<ContactUser> contacts, ArrayList<OnlineUser> others){
        mainMenuMainPanel.updateUsers(contacts, others);
    }

    /**
     * This method updates the chats by calling the method updateChats in mainMenuMainPanel
     * @param chats - a String array used to store the chats and put them inside a JList
     */
    public void updateChats(String[] chats){
        mainMenuMainPanel.updateChats(chats);
    }
    public void updatePanels(){
        mainMenuMainPanel.revalidate();
        mainMenuMainPanel.repaint();
    }

    public String whichChat(String[] choice){
        String retValue = (String) JOptionPane.showInputDialog(null, "Which chat do you want to open?", "Open chat", JOptionPane.QUESTION_MESSAGE, null, choice, choice[0]);
        return retValue;
    }
}
