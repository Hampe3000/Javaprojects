package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * This class creates the different menus and buttons used on the mainPanel and adds actionListeners to them.
 */
public class MainMenuMainPanel extends JPanel implements ActionListener{

    private Controller controller;
    private int width;
    private int height;

    private RigthPanel rightPanel;
    private LeftPanel leftPanel;
    private JMenuBar menuBar;

    /**
     * This constructor takes the parameters and creates a new BorderLayout, calls setUp-method
     * @param controller - Controller
     * @param width - the width of the window
     * @param height - the height of the window
     */
    public MainMenuMainPanel(Controller controller, int width, int height){
        super(new BorderLayout());
        this.controller = controller;
        this.width = width;
        this.height = height;
        this.setSize(width, height);

        setUp();
    }

    /**
     * This method is used to set up the panels with the menus received from the method menuBarSetup()
     */
    private void setUp() {
        menuBar = menuBarSetup();
        this.add(menuBar, BorderLayout.NORTH);

        rightPanel = new RigthPanel(controller);
        leftPanel = new LeftPanel(controller, width, height);
        JPanel chatsAndUsers = new JPanel(new GridLayout(0, 2));

        chatsAndUsers.add(leftPanel);
        chatsAndUsers.add(rightPanel);

        this.add(chatsAndUsers, BorderLayout.CENTER);
    }

    /**
     * This method creates and sets up a JMenuBar that is returned.
     * @return jMenuBar : JMenuBar, this is the JMenuBar that contains the JMenu items that are set up in this method.
     */
    private JMenuBar menuBarSetup() {
        // Create the JMenuBar and the menus it contains
        JMenuBar jMenuBar = new JMenuBar();
        JMenu optionsMenu = new JMenu("Options");
        JMenu statusMenu = new JMenu("Status");
        JMenu logoutMenu = new JMenu("Logout");

        // optionsMenu buttons
        JMenuItem optionA = new JMenuItem("Create new chat");
        JMenuItem optionB = new JMenuItem("Open chat");
        JMenuItem optionC = new JMenuItem("Option C");

        optionA.addActionListener(l -> createChat());
        optionB.addActionListener(l -> openChat());
        optionC.addActionListener(this);

        optionsMenu.add(optionA);
        optionsMenu.add(optionB);
        optionsMenu.add(optionC);

        // statusMenu buttons
        JMenuItem onlineOptionA = new JMenuItem("Online");
        JMenuItem onlineOptionB = new JMenuItem("Offline");
        JMenuItem onlineOptionC = new JMenuItem("Do not disturb");

        onlineOptionA.addActionListener(this);
        onlineOptionB.addActionListener(this);
        onlineOptionC.addActionListener(this);

        statusMenu.add(onlineOptionA);
        statusMenu.add(onlineOptionB);
        statusMenu.add(onlineOptionC);

        // logout Button
        JMenuItem logoutButton = new JMenuItem("Logout");
        logoutButton.addActionListener(l -> controller.logout());
        logoutMenu.add(logoutButton);

        // Add all menus to the menu bar
        jMenuBar.add(optionsMenu);
        jMenuBar.add(statusMenu);
        jMenuBar.add(logoutMenu);

        return jMenuBar;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JMenuItem thing = (JMenuItem) e.getSource();
        System.out.println(thing.getText());
    }

    /**
     * This method updates the contact and onlineUsers lists by calling the method updateUsers in rightPanel
     * @param contacts - an ArrayList containing ContactUser objects
     * @param others   - an ArrayList containing OnlineUser objects
     */
    public void updateUsers(ArrayList<ContactUser> contacts, ArrayList<OnlineUser> others){
        rightPanel.uppdate(contacts, others);
    }

    /**
     * Creates a new chat with the given chatName from the user
     */
    public void createChat(){
       String chatName = JOptionPane.showInputDialog(this, "Please enter the name for your chat");
       controller.createNewChat(chatName);
    }

    public void openChat(){
        controller.displayChat();
    }

    public void updateChats(String[] chats){
        leftPanel.updateChatList(chats);
    }

    public RigthPanel getRightPanel() {
        return rightPanel;
    }

    public void setRightPanel(RigthPanel rightPane) { rightPanel = rightPane; }

    public LeftPanel getLeftPanel() {
        return leftPanel;
    }

    public void setLeftPanel(LeftPanel leftPane) {
        leftPanel = leftPane;
    }

    public void setContacts(){}
}
