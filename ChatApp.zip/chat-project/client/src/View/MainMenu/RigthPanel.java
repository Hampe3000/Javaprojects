package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * This class creates the onlineList and contactList on the right side of the mainframe, it is also responsible for updating them
 */
public class RigthPanel extends JPanel {

    private Controller controller;

    private JList<Object> onlineList;
    private JList<Object> contactList;

    private JPanel onlineTest;
    private JPanel contactTest;

    /**
     * This constructor only needs the controller as a parameter, it creates a new BorderLayout and calls the setUp-method
     * @param controller - Controller
     */
    public RigthPanel(Controller controller) {
        super(new BorderLayout());
        this.controller = controller;

        setup();
    }

    /**
     * This method creates the onlineList and contactList as JLists, sets the specifications and adds them to the contacsAndOnline JSplitPane
     */
    private void setup() {
        onlineList = new JList<>();
        contactList = new JList<>();

        JScrollPane onlineScrollPane = new JScrollPane();
        JScrollPane contactScrollPane = new JScrollPane();

        onlineScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        contactScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        onlineScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        contactScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        onlineTest = new JPanel(new GridLayout(0, 1));
        contactTest = new JPanel(new GridLayout(0, 1));

        onlineScrollPane.setViewportView(onlineTest);
        contactScrollPane.setViewportView(contactTest);

        JSplitPane contactsAndOnline = new JSplitPane(JSplitPane.VERTICAL_SPLIT, contactScrollPane, onlineScrollPane);
        contactsAndOnline.setDividerLocation(300);

        this.add(contactsAndOnline);
    }

    public void addOnlineUser(OnlineUser newOnlineUser) {
        onlineTest.add(newOnlineUser);
    }

    public void addContactUser(ContactUser contactUser){
        contactTest.add(contactUser);
    }

    /**
     * This method updates the panels by removing all the old content and repopulates the panel with all the users found in the iteration of the arrayLists.
     * @param contacts - ArrayList<ContactUser>
     * @param others   - ArrayList<OnlineUser>
     */
    public void uppdate(ArrayList<ContactUser> contacts, ArrayList<OnlineUser> others){
        contactTest.removeAll();
        onlineTest.removeAll();
        for (int i = 0; i < contacts.size(); i++) {
            contactTest.add(contacts.get(i));
        }
        for (int i = 0; i < others.size(); i++) {
            onlineTest.add(others.get(i));
        }
    }
}
