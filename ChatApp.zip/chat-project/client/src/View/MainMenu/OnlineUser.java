package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

/**
 * This class creates the onlineUser-list containing a userName and a button
 */
public class OnlineUser extends JPanel {

    private Controller controller;
    private String name;
    private boolean isNotContact;

    private JLabel nameLabel;
    private JButton button;

    /**
     * This constructor takes the parameters and creates a new BorderLayout, calls the setUp-method
     * @param controller - Controller
     * @param name - the username
     * @param isNotContact - a boolean that checks if the user is a contact or not
     */
    public OnlineUser(Controller controller, String name, boolean isNotContact) {
        super(new BorderLayout());
        this.controller = controller;
        this.name = name;
        this.isNotContact = isNotContact;

        setup();
    }

    /**
     * This method creates the panel, label and button, if the person in the list is already a contact then the button is not enabled.
     */
    private void setup(){
        this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.setBackground(Color.white);

        JPanel profile = new JPanel(new GridLayout(0, 2));
        profile.setBackground(Color.white);

        nameLabel = new JLabel(name);
        button = new JButton("Add");
        button.setEnabled(isNotContact);
        button.setVisible(true);
        button.addActionListener(l -> controller.addNewContact(nameLabel.getText()));

        profile.add(nameLabel);
        profile.add(button);

        this.add(profile, BorderLayout.CENTER);
    }

}
