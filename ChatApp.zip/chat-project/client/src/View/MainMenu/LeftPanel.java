package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;

/**
 * This class is used to create the layout and design of the list containing the created chats on the left
 */
public class LeftPanel extends JPanel {

    private Controller controller;
    private int width;
    private int height;

    // Object lists
    private JScrollPane jScrollPane;
    private JList<String> chatsList;
    private int selectedChat = 0;

    /**
     * This constructor takes the parameters needed to create a chats-list, creates a new BorderLayout and calls the setUp-method.
     * @param controller - Controller
     * @param width - sets the width of the list
     * @param height - sets the height of the list
     */
    public LeftPanel(Controller controller, int width, int height){
        super(new BorderLayout());
        this.controller = controller;
        this.width = width;
        this.height = height;

        setup();
    }

    /**
     * This method creates the chats-list and specifies the different options for it
     */
    private void setup() {

        // Chats object list
        chatsList = new JList<String>();
        chatsList.setLocation(0, height / 8);
        chatsList.setSize(width / 2, height - (height / 4));

        JScrollPane chatsListScroll = new JScrollPane();
        chatsListScroll.setViewportView(chatsList);
        chatsListScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        chatsListScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        //Adding a selectionListener
        /*chatsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        chatsList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if(!e.getValueIsAdjusting()){
                    controller.displayChat();
                }
            }
        });
        chatsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);*/
        this.add(chatsListScroll);
    }


    /**
     * Fills the JPanel with String[] chats
     * @param chats - a string array of chats
     */
    public void updateChatList(String[] chats){
        chatsList.setListData(chats);
    }

    /**
     * Used for getting the selected chats index
     * @return index || 0
     */
    public int getChatIndex(){
        // Todo: This could become a future problem.
        int index = chatsList.getSelectedIndex();
        if (index > 0) {
            return index;
        }
        else {
            return 0;
        }
    }
}
