package View.MainMenu;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

/**
 * This clas creates the contacts-list containing username and status in the up-right corner of the mainframe
 */
public class ContactUser extends JPanel {

    private Controller controller;
    private String name;
    private Color statusColor;

    private JLabel nameLabel;
    private JPanel linePanel;

    /**
     * This constructor takes the parameters needed to create the contacts-list, creates a new BorderLayout and calls the setUp-method.
     * @param controller - Controller
     * @param name - username
     * @param statusColor - displays different colors depending on if the user is online/offline
     */
    public ContactUser(Controller controller, String name, Color statusColor) {
        super(new BorderLayout());
        this.controller = controller;
        this.name = name;
        this.statusColor = statusColor;

        setup();
    }

    /**
     * This method sets up the labels and panels used to create layout and design of the contacts-list
     */
    private void setup() {
        this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.setBackground(Color.white);

        JPanel profile = new JPanel(new GridLayout(0, 3));
        profile.setBackground(Color.white);

        nameLabel = new JLabel(name);
        linePanel = new JPanel(new BorderLayout());
        linePanel.setBackground(Color.WHITE);

        JPanel n = new JPanel();
        n.setBackground(statusColor);
        linePanel.add(n, BorderLayout.WEST);

        profile.add(nameLabel);
        profile.add(linePanel);
        profile.add(new JButton("Send love"));

        this.add(profile);
    }
}
