package View.Chat;


import javax.swing.*;
import java.awt.*;

/**
 * @author Eddie Peters
 * This class is responsible for creating the layout and displaying the different objects correctly in the onlineList.
 */
public class Participant extends JPanel {

    private Image image;
    private String userName;
    private Boolean isOnline;

    /**
     * This constructor takes the parameters needed to create the onlineList, creates a new BorderLayout and calls the setUp-method.
     * @param image - Image
     * @param userName - String
     * @param isOnline - Boolean
     */
    public Participant( Image image, String userName, Boolean isOnline){
        super(new GridLayout(0,3));
        this.image = image;
        this.userName = userName;
        this.isOnline = isOnline;

        setUp();
    }

    /**
     *This method creates the layout and creates labels for each of the components that are going to be displayed in the onlineList.
     */
    public void setUp(){

        //set border
        this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.setBackground(Color.white);


        //set JPanel with grid
        JPanel panel = new JPanel(new GridLayout(1,0));
        panel.setBackground(Color.white);

        //Image
        JLabel imageLbl = new JLabel();
        imageLbl.setIcon(new ImageIcon(image));
        panel.add(imageLbl);

        //UserName
        JLabel userNamelbl = new JLabel();
        userNamelbl.setText(userName);
        panel.add(userNamelbl);


        //Status
        JPanel linePanel = new JPanel(new BorderLayout());
        linePanel.setBackground(Color.white);
        JPanel status = new JPanel();

        //Changes the color of the status depending on if the user is online/offline
        if(isOnline){
            status.setBackground(new Color(0,200,0));
            // statuslbl.setBackground(new Color(63,200,145));
        } else{
            status.setBackground(Color.GRAY);
        }
        linePanel.add(status);
        panel.add(linePanel);

        this.add(panel);
    }

}
