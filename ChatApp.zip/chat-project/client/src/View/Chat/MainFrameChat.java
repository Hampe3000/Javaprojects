package View.Chat;

import Controller.Controller;
import View.MainMenu.MainMenuMainPanel;

import javax.swing.*;
import java.awt.*;


/**
 * This class contains the frame for the chat window
 */
public class MainFrameChat extends JFrame {

    private Controller controller;
    private int width;
    private int height;
    private MainPanelChat mainPanelChat;
    private int ID;

    /**
     * This is the constructor for the frame, every frame has an ID.
     * @param controller the controller used for this frame
     * @param width the width for the frame
     * @param height the height for the fram
     * @param ID the ID for the frame
     * @param chatname the name of the chat
     */
    public MainFrameChat(Controller controller, int width, int height, int ID, String chatname){
        super(chatname);
        this.controller = controller;
        this.height = height;
        this.width = width;
        this.ID = ID;

        this.setResizable(true);
        this.setSize(width, height);
        mainPanelChat = new MainPanelChat(this, this.controller, this.width, this.height, ID);
        this.setContentPane(mainPanelChat);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    /**
     * This method updates the chat every time a new message is received.
     * @param ID the ID for the chat to be updated
     * @param messages the message to be sent
     * @param participants for all participant that is in the chat to be update
     */
    public void UpdateChats(int ID, MessageDialog[] messages, Participant[] participants){
        if(this.ID == ID){
            if (mainPanelChat != null) {
                mainPanelChat.updateConversation(messages, participants);
            }
            else {
                System.out.println("MainFrameChat.java: MainPanelChat is null.");
            }
        }
    }

    public int getID(){
        return ID;
    }

    /**
     * @param skit
     * @return
     */
    public String addToIngvar02ServiceChat(String[] skit){
        String retValue = (String) JOptionPane.showInputDialog(null, "Who do you want to add?", "Add to contact", JOptionPane.QUESTION_MESSAGE, null, skit, skit[0]);
        return retValue;
    }


    /**
     * This method update the text area after every sent message so it is clear for next message
     */
    public void updatePanels(){
        mainPanelChat.revalidate();
        mainPanelChat.repaint();
    }

    public void clearTextArea(){
        mainPanelChat.clearTextArea();
    }

}
