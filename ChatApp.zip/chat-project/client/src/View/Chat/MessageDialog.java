package View.Chat;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

/**
 * @author Eddie Peters
 * This class is responsible for creating the layout and displaying the different objects correctly in the message.
 */
public class MessageDialog extends JPanel {

    private Controller controller;
    private boolean isMyMessage;
    private String text;
    private String sender;
    private String time;
    private Image image;

    /**
     * This constructor takes the parameters needed to create a message, creates a new BorderLayout and calls the setUp-method.
     * @param controller - Controller
     * @param sender - String
     * @param text - String
     * @param time - String
     * @param image - Image
     */
    public MessageDialog(Controller controller, String sender, String text, String time, Image image){
        super(new BorderLayout());
        this.controller = controller;
        this.sender = sender;
        this.text = text;
        this.time = time;
        this.image = image;

        setUp();
    }

    /**
     * This method creates the layout and creates labels for each of the components that are going to be displayed in the messageChat.
     */
    public void setUp(){

        int i = 2;
        if(text != null && text != ""){
            i++;
        }
        if(image != null){
            i++;
        }

        this.setBorder(BorderFactory.createEmptyBorder(10,10, 10, 10));
        this.setBackground(Color.white);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.setBackground(Color.white);


        //Changes the background depending on who sent the message
        if(controller.messageDialogUpdate(sender)){
            panel.setBackground(new Color(131,220,185));
        } else{
            panel.setBackground(new Color(131,200,220));
        }


        //Sender
        JLabel senderLbl = new JLabel();
        senderLbl.setText(this.sender);
        panel.add(senderLbl);


        //Image
        if(image != null) {
            JLabel imagelbl = new JLabel();
            imagelbl.setIcon(new ImageIcon(image));
            panel.add(imagelbl);
        }


        //Message
        if(text != null && text != "") {
            JLabel messagelbl = new JLabel();
            messagelbl.setText(this.text);
            panel.add(messagelbl);
        }

        //TimeSent
        JLabel timeSentLbl = new JLabel();
        timeSentLbl.setText(this.time);
        panel.add(timeSentLbl);

        this.add(panel);
    }

}