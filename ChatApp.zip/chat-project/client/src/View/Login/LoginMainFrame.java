package View.Login;

import Controller.Controller;

import javax.swing.*;

/**
 * This class is used to create the frame for the loginWindow.
 */
public class LoginMainFrame extends JFrame {

    private LoginMainPanel mainPanel;
    private Controller controller;
    private int width;
    private int height;

    /**
     * This constructor creates a new LoginMainFrame
     * @param controller - Controller
     * @param width - the width of this frame
     * @param height . the height of this frame
     */
    public LoginMainFrame(Controller controller, int width, int height){
        super("Chat system");

        this.controller = controller;
        this.width = width;
        this.height = height;
        this.setSize(width, height);

        mainPanel = new LoginMainPanel(controller, width, height);
        this.setContentPane(mainPanel);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * This method sends an error message to the user
     * @param error - an error message explaining the error to the user
     */
    public void displayLoginError(String error){
        mainPanel.displayLoginError(error);
    }

    public LoginMainPanel getMainPanel() {
        return mainPanel;
    }
}
