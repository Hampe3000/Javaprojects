package View.Login;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * This class is responsible for creating the layout and displaying the different components correctly in the LoginMainFrame.
 */
public class LoginMainPanel extends JPanel {

    private Controller controller;
    private int width;
    private int height;

    /**
     * This constructor creates a new BorderLayout and calls the setUp-method.
     * @param controller - Controller
     * @param width      - The width of the window
     * @param height     - The height of the window
     */
    public LoginMainPanel(Controller controller, int width, int height) {
        super(new BorderLayout());
        this.controller = controller;
        this.width = width;
        this.height = height;

        setup();
    }

    /**
     *This method creates the layout and creates the components displayed in the LoginFrame.
     * Adds ActionListeners
     */
    private void setup() {

        JPanel splitPanel = new JPanel(new GridLayout(0, 2));
        JPanel rightPanel = new JPanel(new GridLayout(3, 0));
        JPanel leftPanel = new JPanel(new BorderLayout());

        leftPanel.setBackground(Color.DARK_GRAY);
        rightPanel.setBackground(Color.WHITE);
        JLabel title = new JLabel("Chat system");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(Color.white);
        leftPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, width / 7));
        leftPanel.add(title, BorderLayout.EAST);

        int rightPanelVertical = 160;
        int rightPanelHorizontal = 10;
        rightPanel.setBorder(BorderFactory.createEmptyBorder(rightPanelVertical, rightPanelHorizontal, rightPanelVertical, rightPanelHorizontal));

        int textInputHorizontal = 10;
        int textInputVertical = 10;

        final JTextField username = new JTextField("Username");
        username.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked (MouseEvent e){
                username.setText("");
            }
        });

        JPanel usernamePanel = new JPanel(new BorderLayout());
        usernamePanel.setBackground(Color.white);
        usernamePanel.setBorder(BorderFactory.createEmptyBorder(textInputVertical, textInputHorizontal, textInputVertical, textInputHorizontal));
        usernamePanel.add(username);

        JPasswordField password = new JPasswordField("Password");
        password.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked (MouseEvent e){
                password.setText("");
            }
        });
        JPanel passwordPanel = new JPanel(new BorderLayout());
        passwordPanel.setBackground(Color.white);
        passwordPanel.setBorder(BorderFactory.createEmptyBorder(textInputVertical, textInputHorizontal, textInputVertical, textInputHorizontal));
        passwordPanel.add(password);

        JPanel buttonInput = new JPanel(new GridLayout(0, 2));
        JPanel signinPanel = new JPanel(new BorderLayout());
        JPanel registerPanel = new JPanel(new BorderLayout());
        buttonInput.setBackground(Color.white);
        signinPanel.setBackground(Color.white);
        registerPanel.setBackground(Color.white);

        int buttonHorizontal = 10;
        int buttonVertical = 10;

        signinPanel.setBorder(BorderFactory.createEmptyBorder(buttonVertical, buttonHorizontal, buttonVertical, buttonHorizontal));
        registerPanel.setBorder(BorderFactory.createEmptyBorder(buttonVertical, buttonHorizontal, buttonVertical, buttonHorizontal));

        JButton signInbtn = new JButton("Sign in");
        signInbtn.addActionListener(l -> controller.login(username.getText(),password.getPassword()));
        signinPanel.add(signInbtn);
        JButton registerbtn = new JButton("Register");
        registerbtn.addActionListener(l -> controller.register());
        registerPanel.add(registerbtn);

        buttonInput.add(signinPanel);
        buttonInput.add(registerPanel);

        rightPanel.add(usernamePanel);
        rightPanel.add(passwordPanel);
        rightPanel.add(buttonInput);

        splitPanel.add(leftPanel);
        splitPanel.add(rightPanel);

        this.add(splitPanel);


    }

    /**
     * This method creates an error-message that will get displayed to the user.
     * @param errorMessage - the error-message displayed to the user
     */
    public void displayLoginError(String errorMessage){
        JOptionPane.showMessageDialog(null, errorMessage, "Error", JOptionPane.INFORMATION_MESSAGE);
    }

}