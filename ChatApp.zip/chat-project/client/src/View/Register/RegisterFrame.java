package View.Register;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

/**
 * This class creates the frame for the register- window
 */
public class RegisterFrame extends JFrame {
    private Controller controller;
    private int width;
    private int height;
    private RegisterPanel regPanel;


    /**
     * This constructor sets the title and creates a new registerPanel.
     * @param controller - Controller
     * @param width - the width of this window
     * @param height - the height of the window
     */
    public RegisterFrame(Controller controller, int width, int height) {
        super("Welcome to Ingvar02 Chat Service ");
        this.controller = controller;
        this.width = width;
        this.height = height;

        this.setResizable(false);
        this.setSize(width, height);
        this.setLocationRelativeTo(null);
        regPanel = new RegisterPanel(controller, width, height);
        this.setContentPane(regPanel);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
