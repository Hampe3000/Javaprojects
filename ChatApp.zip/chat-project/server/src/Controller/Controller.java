package Controller;

import Model.*;
import View.MainFrame;

import java.util.Date;

/**
 * This class contains methods that handels all incoming events from the client
 */
public class Controller {

    private MainFrame mainFrame;
    private UpdateLog updateLog;
    private Logger logger;


    /**
     * This is the constructor for the class, and it opens the GUI and
     * fills it with incoming information
     */
    public Controller(){
        mainFrame = new MainFrame(this);
        logger = new Logger("files/Logs/ServerLog.txt"); // todo assign filePath
        updateLog = new UpdateLog(this, logger);

         Server server = new Server(1337, logger);
        // TestClient client = new TestClient("localhost", 1337);

    }

    // Logger controller
    public void setStartDate(String text) {
        String[] textSplit = text.split("-");

        Date date = new Date(Integer.parseInt(textSplit[0]),
                Integer.parseInt(textSplit[1]),
                Integer.parseInt(textSplit[2]),
                Integer.parseInt(textSplit[3]),
                Integer.parseInt(textSplit[4]),
                0
        );

        updateLog.setStartDate(date);
    }

    public void setEndDate(String text) {
        String[] textSplit = text.split("-");

        Date date = new Date(Integer.parseInt(textSplit[0]),
                Integer.parseInt(textSplit[1]),
                Integer.parseInt(textSplit[2]),
                Integer.parseInt(textSplit[3]),
                Integer.parseInt(textSplit[4]),
                0
        );

        updateLog.setEndDate(date);
    }

    public void setFlowing(boolean flowing) {
        updateLog.setFlowing(flowing);
    }

    public void setLog(String[] showLog) {
        mainFrame.getMainPanel().setLog(showLog);
    }
}
