package View;

import Controller.Controller;

import javax.swing.*;


/**
 * This class is the frame for the servers logg
 */
public class MainFrame extends JFrame {

    private Controller controller;
    private MainPanel mainPanel;

    /**
     * @param controller the controller used for the frame
     */
    public MainFrame(Controller controller) {
        super("Logs");
        this.setSize(800, 600);

        this.controller = controller;
        mainPanel = new MainPanel(controller);

        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(mainPanel);
        this.setVisible(true);
    }

    public MainPanel getMainPanel() {
        return mainPanel;
    }
}
