package View;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.chrono.JapaneseDate;

public class MainPanel extends JPanel {

    private Controller controller;

    private JList<String> logs;
    private JRadioButton showFlow;
    private JRadioButton showTimeFrame;

    private JTextField startDateInput;
    private JTextField endDateInput;

    private JLabel startDateLabel;
    private JLabel endDateLabel;


    /**
     * @param controller the controller used for this panel
     */
    public MainPanel(Controller controller) {
        super(new BorderLayout());

        this.controller = controller;

        setup();
    }

    /* The GUI for the loggs are set up in this method */
    private void setup() {
        JPanel optionsPanel = new JPanel(new GridLayout(3, 2));
        ButtonGroup radioButtonGroup = new ButtonGroup();

        showFlow = new JRadioButton("Flowing");
        showFlow.addActionListener(l -> radioButtonAction(showFlow));
        radioButtonGroup.add(showFlow);
        optionsPanel.add(showFlow);
        showFlow.setEnabled(true);

        showTimeFrame = new JRadioButton("Timeframe");
        showTimeFrame.addActionListener(l -> radioButtonAction(showTimeFrame));
        radioButtonGroup.add(showTimeFrame);
        optionsPanel.add(showTimeFrame);

        startDateLabel = new JLabel("Start (YYYY-MM-DD-HH-MM)");
        optionsPanel.add(startDateLabel);

        endDateLabel = new JLabel("End (YYYY-MM-DD-HH-MM)");
        optionsPanel.add(endDateLabel);

        startDateInput = new JTextField();
        startDateInput.addActionListener(l -> controller.setStartDate(startDateInput.getText()));
        optionsPanel.add(startDateInput);

        endDateInput = new JTextField();
        endDateInput.addActionListener(l -> controller.setEndDate(endDateInput.getText()));
        optionsPanel.add(endDateInput);

        logs = new JList<>();
        JScrollPane scroll = new JScrollPane();
        scroll.setViewportView(logs);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        this.add(optionsPanel, BorderLayout.NORTH);
        this.add(scroll, BorderLayout.CENTER);
    }


    public void setLog(String[] showLog) {
        logs.setListData(showLog);
    }

    /**
     * This method checks if the server gets requests from the client and update if it does
     * @param jRadioButton listen for actions
     */
    private void radioButtonAction(JRadioButton jRadioButton) {
        if (jRadioButton.getText().equals("Flowing")){
            controller.setFlowing(true);
        }
        else {
            controller.setFlowing(false);
        }

    }

}
