package Model.client;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * This class handels all new chats that are created and all participant that will be added
 */
public class Chat implements Serializable {
    private ArrayList<User> participants;
    private ArrayList<Message> messages;
    private int chatID;
    private String nameOfChat;

    /**
     * This is the constructor that is called when a new chat is created
     * @param participants all participant in the chat
     * @param messages all messages in the chat
     * @param nameOfChat the name of the chat
     */
    public Chat(ArrayList<User> participants, ArrayList<Message> messages, String nameOfChat) {
        this.participants = participants;
        this.messages = messages;
        chatID = -1;
        this.nameOfChat = nameOfChat;
    }


    /**
     * This method is used when someone wants to add an online user or contact user to a chat
     * @param user the user to be added to a chat
     */
    public void addParticipant(User user){
        participants.add(user);
    }

    /**
     * This method is called when the current user wants to leave a chat
     * @param usel removes the current user from a chat
     */
    public void removeParticipant(User usel){
        for (int i = 0; i < participants.size(); i++) {
            if(participants.get(i).getUserName().equals(usel.getUserName())){
                participants.remove(i);
                break;
            }
        }
    }

    /**
     * This method add a new message to the chat
     * @param msg the message to be added
     */
    public void addMessage(Message msg){
        messages.add(msg);
    }

    // Method not implemented
    public void removeMessage(Message msg){
        for (int i = 0; i < messages.size(); i++) {
            if(messages.get(i).getTimeSend() == msg.getTimeSend()){
                messages.remove(i);
                break;
            }
        }
    }

    // GETTER AND SETTER
    public ArrayList<User> getParticipants() {
        return participants;
    }

    public void setParticipants(ArrayList<User> participants) {
        this.participants = participants;
    }

    public ArrayList<Message> getMessages() {
        return messages;
    }

    public int getChatID() {
        return chatID;
    }

    public void setChatID(int chatID) {
        this.chatID = chatID;
    }

    public void setMessages(ArrayList<Message> messages) {
        this.messages = messages;
    }

    public String getNameOfChat() {
        return nameOfChat;
    }

    public void setNameOfChat(String nameOfChat) {
        this.nameOfChat = nameOfChat;
    }
}
