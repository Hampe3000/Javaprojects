package Model.client.Request;

import Model.client.*;

/**
 * This is an extension of the general Request class. It's used when the client wants to send a message object to the server.
 * @author Hampus Oxenholt, Eddie Peters & Alicia Sondh
 */
public class MessageRequest extends Request {
    private Message message;

    /**
     * This is the constructor it calls the superClass constructor and then sets the instance variable to the value in the parameter.
     * @param requestType is what kind of request this is.
     * @param message is the message to be sent to the server.
     */
    public MessageRequest(RequestType requestType, Message message) {
        super(requestType);
        this.message = message;
    }

    //getter
    public Message getMessage() {
        return message;
    }
}
