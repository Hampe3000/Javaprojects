package Model.client.Request;

/**
 * This is an enum used to tell the server what to do with a received object.
 * @author Hampus Oxenholt, Eddie Peters & Alicia Sondh
 */
public enum RequestType {
    login, // user
    register, // ok = user !ok = string
    send_message, // chat
    create_chat, // chat
    leave_chat, // chat except sender void
    add_to_chat, // chat
    update_status, // user
    log_out

}
