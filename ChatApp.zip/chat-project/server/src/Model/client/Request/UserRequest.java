package Model.client.Request;

import Model.client.*;

/**
 * This is an extension of the general Request class. It's used when the client wants to send a user object to the server.
 * @author Hampus Oxenholt, Eddie Peters & Alicia Sondh
 */
public class UserRequest extends Request{
    private User user;

    /**
     * This is the constructor it calls the superClass constructor and then sets the instance variable to the value in the parameter.
     * @param requestType is what kind of request this is.
     * @param usel is the user to be sent to the server.
     */
    public UserRequest(RequestType requestType, User usel) {
        super(requestType);
        user = usel;
    }

    //getter
    public User getUser() {
        return user;
    }
}
