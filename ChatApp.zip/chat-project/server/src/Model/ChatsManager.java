package Model;

import Model.client.Chat;
import java.io.*;

/**
 * ChatsManager is a class made to handle any incoming chat objects.
 */
public class ChatsManager {
    private String path;

    /**
     * Constructor to set the path for the file in use.
     * @param path - String, getting a string of a path to a file, file path has its origin in Server.java
     */
    public ChatsManager(String path){
        this.path = path;
    }

    /**
     * newChat is a method to create a new chat, it gets called in task when a user sends a chat request.
     * @param newChat - Chat, an object with information about ID, participants, messages and name of chat. See Chat.java
     * @return newChat, when a new chat is being requested, it is the servers job to set an ID and inform the client
     * with the new ID and saved information.
     */
    public Chat newChat(Chat newChat){
       newChat.setChatID(getNewId());
       writeChat(newChat);
       return newChat;
    }

    /**
     * writeChat is a method made to create a unique file for each new chat, the file path is made out from an ID given
     * the chat in newChat.java. The first information about the chat is saved throug an objectOutputStream
     * @param chat - Chat, an object with information about participants, messages and name of chat. See Chat.java
     */
    public void writeChat(Chat chat){

        try {
            String saveChat = path + "/" + chat.getChatID();
            File chatFile = new File(saveChat);

            if(!chatFile.exists()){
                chatFile.createNewFile();
            }

            ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(chatFile));
            objectOutputStream.writeObject(chat);
            objectOutputStream.flush();
            objectOutputStream.close();
        }
        catch (Exception ex) {
            System.out.println("ChatsManager.java: writeChat Error: " + ex);
        }
    }

    /**
     * Whenever there is an event occurring in the chat, this method will be called and set the new data in the
     * associated file.
     * @param chat - Chat, an object with information about participants, messages and name of chat. See Chat.java
     */
    public void updateChat(Chat chat) {
        try {
            String saveChat = path + "/" + chat.getChatID();
            File chatFile = new File(saveChat);

            if(chatFile.exists()){
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(chatFile));
                objectOutputStream.writeObject(chat);
                objectOutputStream.flush();
                objectOutputStream.close();
            }
        }
        catch (Exception ex) {
            System.out.println("ChatsManager.java: updateChat Error: " + ex);
        }
    }

    /**
     * loadChat is a method to get data about a chat from the associated file
     * @param id - int, chat ID
     * @return newChat, all new and old information about the chat. Returns null if file doesn't exist
     */
    public Chat loadChat(int id) {
        Chat newChat = null;

        try {
            String saveChat = path + "/" + id;
            File chatFile = new File(saveChat);

            if (!chatFile.exists()) {
                return null;
            }

            ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(chatFile));
            newChat = (Chat) objectInputStream.readObject();
            objectInputStream.close();
        }
        catch (Exception ex) {
            System.out.println("ChatsManager.java: loadChat Error: " + ex);
        }

        return newChat;
    }

    /**
     * getNewId is a method to decide the chats ID, every ID needs to be personal and this method make sure it is.
     * @return new chat ID
     */
    private int getNewId(){
        File chatDirectory = new File(path);
        String contents[] = chatDirectory.list();

        if (contents == null) {
            return 0;
        }
        else {
            return (contents.length + 1);
        }
    }
}
