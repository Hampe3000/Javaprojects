package Model;

import Model.client.Request.UserRequest;
import Model.client.Status;
import Model.client.User;

import java.io.*;
import java.util.ArrayList;

/**
 * UserManager is a class to handle any incoming user objects.
 */
public class UserManager {
    private String filePath;
    private ArrayList<User> onlineList;

    /**
     * Constructor to create an ArrayList and instantiate filepath
     * @param filePath String, a file path with origins in server.java
     */
    public UserManager(String filePath){
        this.filePath = filePath;
        onlineList = new ArrayList<User>();
    }

    /**
     * This method gets called when a new user registers, it creates a new file with the username as an ID to reach the
     * file. Saves profile picture, username and password into the file. Also sets the user status to online.
     * @param userInfo UserRequest -
     */
    public void registerUser(UserRequest userInfo) {

        try {
            String userFile = filePath + "/" + userInfo.getUser().getUserName();
            File file = new File(userFile);

            if (!file.exists()){
                file.createNewFile();
            }

            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(userFile));
            oos.writeObject(userInfo.getUser());
            oos.flush();
            oos.close();
        }catch (Exception e){
            System.out.println("UserManager.java error");
        }

        User user = userInfo.getUser();
        user.setStatusName("Online! :)");
        user.setCurrentStatus(Status.online);
        onlineList.add(user);
    }

    /**
     * This method gets called when someone logs in on an existing profile. The purpose is to retrieve all
     * information about this user from associated file.
     * @param userName String, to identify which map that belongs to this current user.
     * @return user, returns a user with all data from last time this user was active
     */
    public User loadUser(String userName){
        User user = null;
        try {
            String userFile = filePath + "/" + userName;
            File file = new File(userFile);

            if (!file.exists()){
                return null;
            }

            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(userFile));
            user = (User) ois.readObject();
            ois.close();

        }catch (Exception e){
            System.out.println("UserManager.java error");
        }

        user.setStatusName("Online! :)");
        user.setCurrentStatus(Status.online);
        onlineList.add(user);
        return user;
    }

    /**
     * This method removes users form the online list when a logout occurs, and sets status to offline
     * @param user User, current user to be logged out from the program
     * @return onlinelist, new updated list with online users
     */
    public ArrayList<User> removeFromOnlineList(User user){
        user.setStatusName("Offline :(");
        user.setCurrentStatus(Status.offline);

        for (int i = 0; i < onlineList.size(); i++) {
            if (onlineList.get(i).getUserName().equals(user.getUserName())) {
                System.out.println("UserManager.java: Removed " + onlineList.get(i).getUserName());
                onlineList.remove(i);
            }
        }

        System.out.println("UserManager.java: Entire online list:");
        for (int i = 0; i < onlineList.size(); i++) {
            System.out.println("UserManager.java: - " + onlineList.get(i).getUserName());
        }

        return onlineList;
    }

    /**
     * Getter for onlineList
     * @return onlineList
     */
    public ArrayList<User> getOnlineList() {
        return onlineList;
    }
}
