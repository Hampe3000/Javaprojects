package Model;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Logger.java handles all the logs on the server by saving the log file to disk,
 * providing the logs in method calls and saving new logs by method calls.
 * @authors Hedda Eriksson, Hampus Oxenholt, Eddie Peters, Ingvar Pétursson, Alicia Sondh & Robin Zhang
 */

public class Logger {
    private SimpleDateFormat dateFormat;
    private Date date;
    private String filePath;


    /*
    * The file structure:
    * Each line in the log file is a single log, and they look like this:
    *
    *   YYYY-MM-DD HH:MM:SS EVENT
    *
    * YYYY  = Year          Character: 0 to 4
    * MM    = Month         Character: 5 to 7
    * DD    = Day           Character: 8 to 10
    * HH    = Hour          Character: 11 to 13
    * MM    = Minute        Character: 14 to 16
    * SS    = Second        Character: 17 to 19
    * EVENT = Event         Character: 20 to end
    *
    * The size of the log is fixed except for the event string.
    * The "Character" colum shows where in the string that part is located.
    * */

    /**
     * This is the constructor that takes the path to the log file as parameter and
     * makes sure that the file exists, if not it creates the file.
     * @param filePath String: Is the path to the log file.
     */
    public Logger(String filePath){
        this.filePath = filePath;

        File file = new File(filePath);

        if (!file.exists()) {
            try {
                file.createNewFile();
            }
            catch (Exception ex) {
                System.out.println("Logger.java: Error: " + ex);
            }
        }
    }

    /**
     * Append a new event to the log file
     * @param ip String: Is the IP address of the client
     * @param event String: Is the event that is being added to the log file
     */
    public void addLog(String ip, String event){
        dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        date = new Date();

        String printToFile = dateFormat.format(date) + " " + ip + " " + event;

        appendToFile(printToFile);
    }

    /**
     * This method returns the entire log
     * @return String[]: Contains the entire log
     */
    public String[] showLog(){
        int fileLength = getAmountOfLines();
        String[] logs = new String[fileLength];

        try {
            BufferedReader bufferedReader = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(filePath)
                    )
            );

            for (int i = 0; i < fileLength; i++) {
                logs[i] = bufferedReader.readLine();
            }

        }
        catch (Exception ex) {
            System.out.println("Logger.java: Error: " + ex);
        }

        return logs;
    }

    /**
     * This method returns all the logs between the two dates given. Observe that in both timeStart and timeEnd
     * it is required that year, month and date is given, if only year is given than Date will interpret it as
     * UNIX time and the filtered date will be approximately 1 january 1970, it should also be observed that
     * hour, minute and seconds are optional but will be handled.
     * @param timeStart Date: Is the start date
     * @param timeEnd Date: Is the end date
     * @return String[]: Are the logs between the start date and end date
     */
    public String[] showLog(Date timeStart, Date timeEnd){
        ArrayList<String> filteredLog = new ArrayList<String>();
        String[] fullLog = showLog();

        try {
            for (int i = 0; i < fullLog.length; i++) {
                // Read the file structure note to understand this
                int year    = Integer.parseInt(getString(fullLog[i], 0, 4));
                int month   = Integer.parseInt(getString(fullLog[i], 5, 7));
                int day     = Integer.parseInt(getString(fullLog[i], 8, 10));
                int hour    = Integer.parseInt(getString(fullLog[i], 11, 13));
                int minute  = Integer.parseInt(getString(fullLog[i], 14, 16));
                int second  = Integer.parseInt(getString(fullLog[i], 17, 19));

                Date temporaryDate = new Date(year, month, day, hour, minute, second);

                if (timeStart.getTime() <= temporaryDate.getTime() && timeEnd.getTime() >= temporaryDate.getTime()) {
                    filteredLog.add(fullLog[i]);
                }

            }
        }
        catch (Exception ex) {
            System.out.println("Logger.java: Error: " + ex);
        }

        // Convert the ArrayList<String> to String[]
        String[] filteredLogArray = new String[filteredLog.size()];

        for (int i = 0; i < filteredLogArray.length; i++) {
            filteredLogArray[i] = filteredLog.get(i);
        }

        return filteredLogArray;
    }

    /**
     * This method gets a string and returns the characters between the start point and the
     * end point from the given string
     * @param text String: Is the given string that characters should be extracted from
     * @param start int: Is the start point
     * @param end int: Is the end point
     * @return String: Is the characters that are extracted from the input string
     */
    private String getString(String text, int start, int end){
        String extractedString = "";

        for (int i = start; i < end; i++) {
            extractedString += text.charAt(i);
        }

        return extractedString;
    }

    /**
     * This method checks how many lines of text there are in the file at filePath.
     * @return int: The amount of lines in the file.
     */
    private int getAmountOfLines(){
        int lineAmount = 0;

        try {
            BufferedReader bufferedReader = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(filePath)
                    )
            );

            String line = bufferedReader.readLine();

            while( line != null ) {
                lineAmount++;
                line = bufferedReader.readLine();
            }
        }
        catch (Exception ex) {
            System.out.println("Logger.java: Error: " + ex);
        }

        return lineAmount;
    }

    /**
     * This method reads the data from a file, appends the new data and then writes the
     * resulting data to the file.
     * @param data
     */
    private void appendToFile(String data) {
        int fileLength = getAmountOfLines();

        // This String array is going to contain all the data from the log file and
        // the new log item, thus the +1.
        String[] fileData = new String[fileLength + 1];
        fileData[fileLength] = data;

        try {
            BufferedReader bufferedReader = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(filePath)
                    )
            );

            // Read all lines of the log file
            for (int i = 0; i < fileLength; i++) {
                fileData[i] = bufferedReader.readLine();
            }

            BufferedWriter bufferedWriter = new BufferedWriter(
                    new OutputStreamWriter(
                            new FileOutputStream(filePath)
                    )
            );

            for (int i = 0; i < fileData.length; i++) {
                if (fileData[i] != null) {
                    bufferedWriter.write(fileData[i] + "\n");
                }
            }
            
            bufferedWriter.flush();

        }
        catch (Exception ex) {
            System.out.println("Logger.java: Error: " + ex);
        }


    }

}
