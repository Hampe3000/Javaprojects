package Model;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 * The class ChangeManager manages the PropertyChangeSupport and syncs the responses to clients.
 * Each task handles a single client and some objects needs to reach all clients, so to reach all
 * output streams, which are located in Task.java, a firePropertyChange() is called with the new
 * object that should be sent to all clients. In all the running tasks the changePrompter() method
 * is called and handles the sending of the object for that specific client.
 * @author Ingvar Pétursson, Hedda Eriksson
 */
public class ChangeManager {

    private PropertyChangeSupport changeSupport;

    /**
     * This is the constructor that creates the PropertyChangeSupport.
     */
    public ChangeManager(){
        changeSupport = new PropertyChangeSupport(this);
    }

    /**
     * This method adds a listener to the PropertyChangeListener, each listener is a Task.java.
     * @param listener PropertyChangeListener:
     */
    public void addListener(PropertyChangeListener listener){
        changeSupport.addPropertyChangeListener(listener);
    }

    /**
     * CallChange is the method which makes the call to all treads changeProperty() in all tasks.
     * @param object Object: Is the object that should be sent to one or more clients.
     * @param propertyName String: This parameter works like an id for the changeProperty() to
     *                             filter out if the object is something that should be sent to
     *                             the client or not.
     */
    public void callChange(Object object, String propertyName){
        changeSupport.firePropertyChange(propertyName, null, object);
    }

    /**
     * This method removes a Task.java object as a listener from the PropertyChangeManager.
     * @param task Task: Is the task that should be remove from the PropertyChangeListener. 
     */
    public void removeListener(Task task) {
        changeSupport.removePropertyChangeListener(task);
    }
}
