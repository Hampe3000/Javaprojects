package Model;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

public class TestClient {


    public TestClient(String ip, int port){
        new StartClient(ip, port).start();
    }

    private class StartClient extends Thread{
        private String ip;
        private int port;

        public StartClient(String ip, int port){
            this.ip = ip;
            this.port = port;
        }


        @Override
        public void run() {
            Socket socket = null;
            try {
                socket = new Socket(ip, port);
                ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(socket.getOutputStream()));

                while(true) {
                    try {
                        System.out.println("Client run while eller nått");
                        String test = "TEST SUCCESS";
                        oos.writeUTF(test);
                        oos.flush();
                        Thread.sleep(1000);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
}
