package Model;

import Model.client.Chat;
import Model.client.Message;
import Model.client.Request.*;
import Model.client.User;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Task is a single running thread which handles a request from the user.
 * It implements Runnable and PropertyChangeListener.
 */
public class Task implements Runnable, PropertyChangeListener {
    private Socket socket;
    private Logger logger;
    private ChangeManager changeManager;
    private ObjectInputStream objectInputStream;
    private Object receivedObject;
    private ObjectOutputStream objectOutputStream;
    private UserManager userManager;
    private ChatsManager chatsManager;
    private User threadUser;

    /**
     * This is the constructor that has the parameter socket which is a connected client and it creates
     * both ObjectInputStream and ObjectOutputStream to send and receive date from and to the client.
     * @param socket Socket: Is the socket which a client has connected to.
     * @param logger is the log where we will log the traffic.
     */
    public Task(Socket socket, Logger logger, ChangeManager changeManager, UserManager userManager, ChatsManager chatsManager){
        this.socket = socket;
        this.logger = logger;
        this.changeManager = changeManager;
        this.userManager = userManager;
        this.chatsManager = chatsManager;

        try {
            // Try to remove BufferedOutputStream.
            objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
            objectOutputStream.flush();
            objectInputStream = new ObjectInputStream(socket.getInputStream());
        }
        catch (Exception ex) {
            System.out.println("Task.java: Error: " + ex);
            ex.printStackTrace();
        }
    }

    /**
     * The run() method checks if the client is sending an object and forwards
     * the received object to requestHandler.
     */
    @Override
    public void run() {
        while(true){
            try {
                receivedObject = objectInputStream.readObject();

                if (receivedObject instanceof Request){
                    logger.addLog(socket.getInetAddress().getHostAddress(),((Request) receivedObject).getRequestType().name());
                    handleRequest(receivedObject);
                }
            }
            catch (IOException ex) {
                try {
                    objectInputStream.close();
                    objectOutputStream.close();
                    break;
                }
                catch (Exception e) {
                    System.out.println("Task.run.java: Error: " + e);
                    e.printStackTrace();
                }
            }
            catch (Exception e){

                System.out.println("Task.java: Error: " + e);
                e.printStackTrace();
            }
        }
    }

    /**
     * The method handleRequest checks what the RequestType is with a switch case algorithm and forwards the object to the
     * correct handler class.
     * @param object Object: Is the object received from the client.
     */
    private void handleRequest(Object object) {

           Request request = (Request) object;

        switch (request.getRequestType()){
            case login:
                DoubleStringRequest login = (DoubleStringRequest) object;
                User currentUser = userManager.loadUser(login.getUsername());
                threadUser = currentUser;
                changeManager.callChange(currentUser, "login");


                break;
            case register:
                UserRequest register = (UserRequest) object;
                userManager.registerUser(register);
                threadUser = register.getUser();
                changeManager.callChange(register.getUser(), "register");

                break;
            case send_message:
                MessageRequest messageR = (MessageRequest) object;
                Message message = messageR.getMessage();
                Chat currentChat = chatsManager.loadChat(message.getChatID());
                currentChat.addMessage(message);
                chatsManager.updateChat(currentChat);
                changeManager.callChange(currentChat, "send_message");

                break;
            case create_chat:

                ChatRequest createChat = (ChatRequest) object;
                Chat newChat = chatsManager.newChat(createChat.getChat());
                changeManager.callChange(newChat, "create_chat");

                break;
            case leave_chat:
                ChatRequest chatChangeRequest = (ChatRequest) object;
                Chat chatChange = chatChangeRequest.getChat();
                chatsManager.updateChat(chatChange);
                changeManager.callChange(chatChange, "leave_chat");
                break;
            case add_to_chat:

                ChatRequest addToChatReq = (ChatRequest) object;
                Chat addToChat = addToChatReq.getChat();
                chatsManager.updateChat(addToChat);
                changeManager.callChange(addToChat, "add_to_chat");

                break;
            case log_out:
                UserRequest userRequest = (UserRequest) object;
                User user = userRequest.getUser();
                changeManager.removeListener(this);
                userManager.removeFromOnlineList(user);
                try {
                    objectOutputStream.close();
                    objectInputStream.close();
                }
                catch (Exception ex) {
                    System.out.println("Task.java: Error: " + ex);
                    ex.printStackTrace();
                }
                changeManager.callChange(user, "log_out");
                break;
            case update_status:
                // This function might be further developed in future updates.
                break;
            default:
                // This function might be further developed in future updates.
                break;
        }

    }

    /**
     * This method listens for events in our various tasks and updates all participants in a chat.
     * @param evt is the event that we listen to.
     */
    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if (evt.getPropertyName().equals("send_message") ||
               evt.getPropertyName().equals("create_chat") ||
               evt.getPropertyName().equals("leave_chat") ||
               evt.getPropertyName().equals("add_to_chat") ||
                evt.getPropertyName().equals("update chats")
        ) {

           Chat chat = (Chat) evt.getNewValue();
           ArrayList<User> participantsList = chat.getParticipants();

           for (int i = 0; i < participantsList.size(); i++) {
                if (participantsList.get(i).getUserName().equals(threadUser.getUserName())) {
                    send(evt.getNewValue());
                }
           }
       }
       else{
            send(evt.getNewValue());
       }
    }

    /**
     * This method sends an object thourhg our streams.
     * @param object that we send.
     */
    private void send(Object object) {
        try {
            objectOutputStream.writeObject(object);
            objectOutputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



