package Model;
import Controller.Controller;
import java.util.Date;

/**
 * This class handles date updates through a thread so that we can filter traffic
 * by start and end date.
 */
public class UpdateLog extends Thread {

    private Controller controller;
    private Logger logger;
    private Date startDate;
    private Date endDate;
    private boolean flowing;

    /**
     * Constructor that creates and starts the thread.
     * With this object we can determine if we want to see the traffic in a flow sequence or filtered by
     * start and end time.
     * @param controller our controller is passed.
     * @param logger our logger is used. Important so that we can collect the data at one location.
     */
    public UpdateLog(Controller controller, Logger logger) {
        this.controller = controller;
        this.logger = logger;
        this.flowing = true;
        startDate = new Date(0);
        endDate = new Date(2100, 01, 01, 01, 01, 01);
        this.start();
    }

    /**
     * sets the start date and time.
     * @param date
     */
    public void setStartDate(Date date) {
            startDate = date;
    }

    /**
     * sets the end date and time.
     * @param date
     */
    public void setEndDate(Date date) {
            endDate = date;
    }


    /**
     * sets the layout of our traffic.
     * @param flowing if true the layout will be flowing. When false we use the filtered view.
     */
    public void setFlowing(boolean flowing) {
        this.flowing = flowing;
    }

    /**
     * This method updates our log so that the user can see the traffic.
     */
    public void run(){

        while(true) {
            try {
                if (flowing) {
                    controller.setLog(logger.showLog());
                }
                else {
                    controller.setLog(logger.showLog(startDate, endDate));
                }

                Thread.sleep(1000);
            }
            catch (Exception ex) {
                System.out.println("UpdateLog.java: Error: " + ex);
            }
        }

    }

}
