package Model;

import Controller.Controller;

import java.beans.PropertyChangeListener;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Server.java is a multi-threaded class that handles our server with a thread-pool so that every client can connect to it.
 * This class handles all the users that are connected, logs the traffic, chats and the functionality of the app.
 * For the program to work, its crucial that our server runs before staring up the clients.
 * @authors Hedda Eriksson, Hampus Oxenholt, Eddie Peters, Ingvar Pétursson, Alicia Sondh & Robin Zhang
 */

public class Server<ChatManager> {
    private Controller controller;
    private ArrayList<Object> userList;
    private ExecutorService threadPool;
    private int port;
    private Socket socket;
    private Task task;
    private Logger logger;
    private ChangeManager changeManager;
    private UserManager userManager;
    private ChatsManager chatsManager;
    private String chatPath;

    /**
     * Constructor that constructs our server with a thread-pool so that we can do various task in parallel.
     * The constructor creates several managers and lists for the program to work correctly.
     * The different manages handles our users, chats and event listeners.
     * our Server-object starts the server and updates our clients which are conected.
     * @param port which port to listen to for connections.
     * @param logger where to log the files.
     */
    public Server(int port, Logger logger){
        this.port = port;
        threadPool = Executors.newFixedThreadPool(1000);
        userList = new ArrayList<Object>();
        this.logger = logger;
        changeManager = new ChangeManager();
        userManager = new UserManager("files/Users");
        chatPath = "files/Chats";
        chatsManager = new ChatsManager(chatPath);
        new StartServer(port).start(); // startar server.
        new UpdateClients().start();
    }


    /**
     * Inner class that operates as a thread and inherits Thread.
     * This class creates method that can start and shutdown our thread-pool.
     */
    private class StartServer extends Thread{
        private int port;
        private ServerSocket serverSocket;

        /**
         * Starts our server.
         * @param port which port to listen to for client connections.
         */
        public StartServer(int port){
            this.port = port;
        }

        /**
         * method shuts down thread-pool.
         */
        public void killServer() {
            threadPool.shutdown();
        }

        /**
         * Method is inherited from Thread-class. This method  runs all the tasks with our thread-pool.
         * In the method we also implemented listener for new tasks so that out thread can work properly.
         */
        @Override
        public void run() {
            System.out.println("Server.java START.");
            try(ServerSocket serverSocket = new ServerSocket(port)) {
                while(true) {
                    try{
                        socket = serverSocket.accept();
                        task = new Task(socket, logger, changeManager, userManager, chatsManager);
                        changeManager.addListener((PropertyChangeListener) task);
                        threadPool.execute(task); // tråd executar task.

                    } catch(Exception e) {
                        e.printStackTrace();
                    }
            }

            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Inner class that inherits Thread and operates as a thread. This thread updates our online-users and
     * chats. This way the user can see how many users are online and a chat-list in "real-time".
     */
    private class UpdateClients extends Thread {

        /**
         * This method updates the user on which users are online and chat-list.
         */
        public void run() {

            while (true) {

                try {
                    Thread.sleep(5000);

                    // Update online users
                    for (int i = 0; i < userManager.getOnlineList().size(); i++) {
                        changeManager.callChange(userManager.getOnlineList().get(i), "update user");
                    }

                    // Update chats
                    File chats = new File(chatPath);
                    String[] chatNames = chats.list();
                    if (chatNames != null) {
                        for (int i = 0; i < chatNames.length; i++) {
                            changeManager.callChange(chatsManager.loadChat(Integer.parseInt(chatNames[i])), "update chats");
                        }
                    }
                } catch (Exception ex) {
                    System.out.println("Server.java: Error: " + ex);
                }
            }
        }
    }

}
