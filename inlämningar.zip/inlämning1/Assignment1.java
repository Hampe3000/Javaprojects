/*
  Author: Hampus Oxenholt
  Id: ai7546
  Study program: DT
*/
import java.util.Scanner;
public class Assignment1{
  static Scanner input = new Scanner(System.in);
  // an array to use for testing, replace as needed to test your code
  static String[][] guestList = {{"Adam Ason", "35"},
                                 {"Berta Bson", "70"},
                                 {"Ceasar Cson", "12"},
                                 {"",""},
                                 {"",""},
                                 {"",""},
                                 {"",""},
                                 {"",""},
                                 {"",""},
                                 {"",""},
                               };



  public static void printGuestList()//the method that displays the guestlist to the user
  {
    boolean allEmpty = true;
    System.out.println("Index Name      Age");
    for (int i=0; i < guestList.length; i++)
    {
      if(guestList[i][0] != null && guestList[i][0] != "")
      {
        System.out.println(i+"     "+guestList[i][0]+" "+guestList[i][1]);
        allEmpty = false;
      }
    }
    if(allEmpty)
    {
      System.out.println("The guestlist is empty.");
    }
    System.out.println();//to make the console more legible
  }

  public static void printStatistics()//the method that displays statistics of the guests
  {

    int numOfGuests = 0;
    int numOfAdults = 0;
    int numOfChildren = 0;
    int minAge = 0;
    int youngestRow = -1;
    int maxAge = 0;
    int oldestRow = -1;
    for (int i=0; i<guestList.length; i++) //assigns start values for minAge&maxAge
    {
      if(guestList[i][0] !=null && guestList[i][0] !="")
      {
        youngestRow = i;
        oldestRow = i;
        minAge = Integer.parseInt(guestList[i][1]);
        maxAge = Integer.parseInt(guestList[i][1]);
        break;
      }
    }
    if(youngestRow != -1)//checks if the array contained anny participants
    {
      for (int i=0; i<guestList.length; i++)
      {
        if(guestList[i][0] !="" && guestList[i][0] != null)
        {
          numOfGuests++;
          if(Integer.parseInt(guestList[i][1]) >13)
          {
            numOfAdults++;
          }
          else
          {
            numOfChildren++;
          }
          if(Integer.parseInt(guestList[i][1]) < minAge)
          {
            minAge = Integer.parseInt(guestList[i][1]);
            youngestRow = i;
          }
          if(Integer.parseInt(guestList[i][1]) > maxAge)
          {
            maxAge = Integer.parseInt(guestList[i][1]);
            oldestRow = i;
          }
        }
      }
      System.out.println("-----Guestlist statistics-----");
      System.out.println("Total number of guests: "+numOfGuests);
      System.out.println("Number of adults:       "+numOfAdults);
      System.out.println("Number of children:     "+numOfChildren);
      System.out.println("The youngest participant was "+guestList[youngestRow][1]+" years old.");
      System.out.println("Their name is "+guestList[youngestRow][0]);
      System.out.println("The oldest participant was "+guestList[oldestRow][1]+" years old.");
      System.out.println("Their name is "+guestList[oldestRow][0]);
      System.out.println();//to make the console more legible
    }
    else
    {
      System.out.println("The guestlist is empty.");
      System.out.println();//to make the console more legible
    }
  }

  public static void addGuest()//method for adding a guest to the list
  {
    int availableIndex =-1;
    for (int i=0; i<guestList.length; i++)//serches for available index
    {
      if(guestList[i][0] == null || guestList[i][0] == "")
      {
        availableIndex = i;
        break;
      }
    }
    if(availableIndex == -1)
    {
      System.out.println("The list is sadly full. :( ");
      System.out.println("Try deleteting someone you don't want to come.");
      System.out.println();//to make the console more legible
    }
    else
    {
      System.out.println("Please fill out the fullname of the guest you wish to add.");
      guestList[availableIndex][0] = input.nextLine();
      System.out.println("please enter this persons age");
      guestList[availableIndex][1] = input.nextLine();
      System.out.println();//to make the console more legible
      System.out.println(guestList[availableIndex][0]+" was added to the guest list");
      System.out.println();//to make the console more legible
    }
  }

  public static void changeNamneOfGuest()//method for changing the name of a guest
  {
    System.out.println("Please chose the index where you would like to change");
    int index = Integer.parseInt(input.nextLine());
    if(guestList[index][0] != null && guestList[index][0] != "" && index >-1 && index < guestList.length)
    {
      System.out.println("Please enter the new name");
      guestList[index][0] = input.nextLine();
      System.out.println();//to make the console more legible
      System.out.println("Change succesful.");
      System.out.println();//to make the console more legible
    }else
    {
      System.out.println("That index does not contain annybody. If you want to see the indexes please print the list (choise 1)");
      System.out.println();//to make the console more legible
    }
  }

  public static void changeAgeOfGuest()//method for changing the age of a guest
  {
    System.out.println("Please chose the index where you would like to change");
    int index = Integer.parseInt(input.nextLine());
    if(guestList[index][0] != null && guestList[index][0] != "" && index >-1 && index < guestList.length)
    {
      System.out.println("Please enter the new age");
      guestList[index][0] = input.nextLine();
      System.out.println();//to make the console more legible
      System.out.println("Change succesful.");
      System.out.println();//to make the console more legible
    }else
    {
      System.out.println("That index does not contain annybody. If you want to see the indexes please print the list (choise 1)");
      System.out.println();//to make the console more legible
    }
  }

  public static void removeGuest()//method for deleting a guest
  {
    System.out.println("Please chose the index where you would like to change");
    int index = Integer.parseInt(input.nextLine());
    if(guestList[index][0] != null && guestList[index][0] != "" && index >-1 && index < guestList.length)
    {
      guestList[index][1] = "";
      guestList[index][0] = "";
      System.out.println("Delete succesful.");
      System.out.println();//to make the console more legible
    }else
    {
      System.out.println("That index does not contain annybody. If you want to see the indexes please print the list (choise 1)");
      System.out.println();//to make the console more legible
    }
  }

  public static void changePlaces()//method for swaping two guests/positions
  {
    System.out.println("Please provide the index you whould like to move");
    int index1 = Integer.parseInt(input.nextLine());
    if(index1 >=0 && index1<guestList.length)
    {
      System.out.println("Plese provide where you want to move it");
      int index2 = Integer.parseInt(input.nextLine());
      if(index2 >=0 && index2<guestList.length)
      {
        String holdName = guestList[index1][0];
        String holdAge = guestList[index1][1];
        guestList[index1][0]=guestList[index2][0];
        guestList[index1][1]=guestList[index2][1];
        guestList[index2][0]=holdName;
        guestList[index2][1]=holdAge;
        System.out.println("Swap complete.");
        System.out.println();//to make the console more legible
      }
      else
      {
        System.out.println("That not a valid index :(");
        System.out.println();//to make the console more legible
      }
    }
    else
    {
      System.out.println("That not a valid index :(");
      System.out.println();//to make the console more legible
    }
  }

  public static void printMenu()//method for displaying the menu
  {
    System.out.println("Program menu");
    System.out.println("1. Print guestlist");
    System.out.println("2. Show statistics for guestlist");
    System.out.println("3. Add guest");
    System.out.println("4. Change name of guest");
    System.out.println("5. Change age of guest");
    System.out.println("6. Delete guest");
    System.out.println("7. Change places of two guests");
    System.out.println("0. Exit");
  }

  public static int makeChoice()//method for taking input from the user
  {
    Scanner inputInt = new Scanner(System.in);
    System.out.print("Make a choice: ");
    int choice = inputInt.nextInt();
    System.out.println();//to make the console more legible
    return choice;
  }

  public static void main(String[] args)//the main method where all other methods are launched as needed
  {
     boolean done = false;
     do
     {
       printMenu();
       switch (makeChoice())
       {
         case 1:
          System.out.println("You chose to print out the guestlist");
          System.out.println();//to make the console stream more legible
          printGuestList();
          break;
         case 2:
          System.out.println("You chose to show the statistics");
          System.out.println();//to make the console stream more legible
          printStatistics();
          break;
        case 3:
          System.out.println("You chose to add a guest");
          System.out.println();//to make the console stream more legible
          addGuest();
          break;
        case 4:
          System.out.println("You chose to change the name of a guest");
          System.out.println();//to make the console stream more legible
          changeNamneOfGuest();
          break;
        case 5:
          System.out.println("You chose to change the age of a guest");
          System.out.println();//to make the console stream more legible
          changeAgeOfGuest();
          break;
        case 6:
          System.out.println("You chose to delete a guest");
          System.out.println();//to make the console stream more legible
          removeGuest();
          break;
        case 7:
          System.out.println("You chose to switch the positioning of a guest");
          System.out.println();//to make the console stream more legible
          changePlaces();
          break;
        case 0:
          System.out.println("Exit");
          done = true;
          break;
        default:
          System.out.println("That is not a valid choise!");
          System.out.println("Valid choises are: 0, 1, 2, 3, 4, 5, 6, & 7");
          break;
       }
     } while (!done);
  }
}
