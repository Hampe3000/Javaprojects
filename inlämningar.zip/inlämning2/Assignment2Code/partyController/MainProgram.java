/*
  Author: Hampus Oxenholt
  Id: ai7546
  Study program: DT
  date: 11/11-2021
*/
package partyController;

import javax.swing.*;


public class MainProgram
{
    public static void main(String[] args)
    {
        int maxNbrOfGuests = 10; // Change thi line later. Only using 10 as a default value to make compilations possible.
        /* Write code to read max number of guests from the user by using one of
         - JOptionPane
         - Scanner and prompt
        */
        boolean done = false;
        String input;
        do{

            input = JOptionPane.showInputDialog(null, "Please provide the maximum number of guests for the event.", "Guest limit", JOptionPane.INFORMATION_MESSAGE);
            try {
                if(input == null || input ==""){
                    System.exit(0);
                }
                else{

                    maxNbrOfGuests = Integer.parseInt(input);
                    if(maxNbrOfGuests > 0){
                    done = true;
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Invalid number of guests!");
                    }
                }
            }
            catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null, "Invalid number of guests!");
            }
        }while (!done);

        Controller controller = new Controller(maxNbrOfGuests);
    }
}
