/*
  Author: Hampus Oxenholt
  Id: ai7546
  Study program: DT
  date: 11/11-2021
*/
package partyModel;

import javax.swing.*;

public class Address {
   /* Declare instance variables for street, city, zip code as String-objects
      and country by using the enum Countries
    */
    private String street;
    private String city;
    private String zipCode;
    private Countries country;

  /* Write a default constructor that gives default values for instance variables.
     Set default values for instance variables by calling the other constructor
     below using the this reserved word and:
     - Alternative 1: with arguments that are default values
       of your choice that will inform a user that this value isn't really set.
     - Alternative 2: Use null for all values and call the constructor below and handle that there.
   */
    public Address(){ //the default constructor never used
       this("Actual lane", "Totally real city", "-1", Countries.Unknown); //call to the other constructor with arguments
       JOptionPane.showMessageDialog(null, "the guest has been added with default adress values"); //message window to inform the user that default values will be used
    }


  /* Write a constructor with parameters for all instance variables
     given above. Set instance variables to values from parameters.

     Check that the values for the parameters street, zipCode and city
     isn't empty Strings or null before assigning the values to the
     corresponding instance variables.
     If any value is empty or null assign a default value of your choice
     that will inform a user that this value isn't really set.

     If the parameter country is null set this to Countries.Unknown
   */
    public Address(String street, String city, String zipCode, Countries country){ //constructor taking 4 arguments then calling set methods to set the values
        setStreet(street);
        setCity(city);
        setZipCode(zipCode);
        setCountry(country);
    }

  /* Implement get- and set-methods for all instance variables.
     Remember to check parameters in set-methods with the same
     rules as in the constructor above.
   */
    public String getStreet(){
        return street;
    }
    public String getCity(){
        return city;
    }
    public String getZipCode(){
        return zipCode;
    }
    public Countries getCountry(){
        return country;
    }
    public void setStreet(String street){ //if provided a valid name that will be used otherwise a default value will be applied
        if(street != null && !street.equals("")){
            this.street = street;
        }
        else{
            if(this.street == null || this.street.equals("")){
                this.street = "Actual lane";
            }
            else{
                JOptionPane.showMessageDialog(null, "Not a valid street name! Street name unchanged"); //informs the user that the previous name remains
            }
        }
    }
    public void setCity(String city){ //if provided a valid name that will be used otherwise a default value will be applied
        if(city != null && !city.equals("")){
            this.city = city;
        }
        else{
            if(this.city == null || this.city.equals("")){
                this.city = "Totally real city";
            }
            else{
                JOptionPane.showMessageDialog(null, "Not a valid city name! City name unchanged"); //informs the user that the previous name remains
            }
        }
    }
    public void setZipCode(String zipCode){ //if provided a valid name that will be used otherwise a default value will be applied
        if(zipCode != null && !zipCode.equals("")){
            this.zipCode = zipCode;
        }
        else{
            if(this.zipCode == null || this.zipCode.equals("")){
                this.zipCode = "-1";
            }
            else{
                JOptionPane.showMessageDialog(null, "Not a valid zip code! Zip code unchanged"); //informs the user that the previous name remains
            }
        }
    }
    public void setCountry(Countries country){
        if(country != null){
            this.country = country;
        }
        else{
            if(this.country == null){
                this.country = Countries.Unknown;
            }
            else{
                JOptionPane.showMessageDialog(null, "Not a valid country! Country unchanged");
            }
        }
    }

  /* Write a toString method to return a String-object made of the address details,
     formatted as one line.
   */

    public String toString() {
        return city + "   " + street + "  " + zipCode + "   " + country.name();
    }
}
