/*
  Author: Hampus Oxenholt
  Id: ai7546
  Study program: DT
  date: 11/11-2021
*/
package partyView;

public enum ButtonType {
    Add,
    Change,
    Delete,
}
