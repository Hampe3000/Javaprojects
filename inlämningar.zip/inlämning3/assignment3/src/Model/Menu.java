package Model;

import Model.Topping.Topping;
import Model.Topping.Toppings;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class Menu {//exist to make the controller look a little neater
    private boolean over18;
    private List<Topping> toppingList;
    private Pizza[] pizzaList;
    private List<Beverage> beverageList;

    public Menu(boolean over18){
        this.over18 = over18;
        toppingList = new ArrayList<Topping>();
        pizzaList = new Pizza[5];
        beverageList = new ArrayList<Beverage>();

        initPizzas();
        initBeverageLIst();
        initToppings();
    }

    private void initPizzas(){//creates preset pizzas
        Pizza pizza = new Pizza("Margherita");
        pizza.addTopping(Toppings.TomatoSauce);
        pizza.addTopping(Toppings.Mozzarella);
        pizza.setCost(60.00);
        pizzaList[0] =pizza;

        pizza = new Pizza("Vesuvio");
        pizza.addTopping(Toppings.TomatoSauce);
        pizza.addTopping(Toppings.Mozzarella);
        pizza.addTopping(Toppings.Ham);
        pizza.setCost(75.00);
        pizzaList[1] =pizza;

        pizza = new Pizza("Hawaii");
        pizza.addTopping(Toppings.TomatoSauce);
        pizza.addTopping(Toppings.Mozzarella);
        pizza.addTopping(Toppings.Ham);
        pizza.addTopping(Toppings.Pineapple);
        pizza.setCost(85.00);
        pizzaList[2] =pizza;

        pizza = new Pizza("Sausage Pizza");
        pizza.addTopping(Toppings.TomatoSauce);
        pizza.addTopping(Toppings.Mozzarella);
        pizza.addTopping(Toppings.Salami);
        pizza.addTopping(Toppings.Peperoni);
        pizza.setCost(85.00);
        pizzaList[3] =pizza;

        pizza = new Pizza("Robin Hood");
        pizza.addTopping(Toppings.TomatoSauce);
        pizza.addTopping(Toppings.Mozzarella);
        pizza.addTopping(Toppings.Mushroom);
        pizza.addTopping(Toppings.Beef);
        pizza.addTopping(Toppings.BearnaiseSauce);
        pizza.setCost(130.00);
        pizzaList[4] =pizza;
    }

    private void initBeverageLIst(){//initializes preset drinks

        Beverage beverage = new Beverage("Coca Cola", 10.00);
        beverageList.add(beverage);

        beverage = new Beverage("Fanta", 10.00);
        beverageList.add(beverage);

        beverage = new Beverage("Sprite", 10.00);
        beverageList.add(beverage);

        beverage = new Beverage("Ramlösa", 10.00);
        beverageList.add(beverage);

        beverage = new Beverage("Carlsberg (Alkohol fri)", 15.00);
        beverageList.add(beverage);

        if(over18){
            beverage = new Beverage("Prips blå", 35.00, 5.0);
            beverageList.add(beverage);

            beverage = new Beverage("Norlands guld", 30.00, 5.0);
            beverageList.add(beverage);

            beverage = new Beverage("Röd vin", 65.00, 14.0);
            beverageList.add(beverage);

            beverage = new Beverage("Vit vin", 60.00, 14.0);
            beverageList.add(beverage);

            beverage = new Beverage("Snaps", 60.00, 35.0);
            beverageList.add(beverage);
        }
    }

    public void initToppings(){//puts the toppings from the interface into an array
        toppingList.add(Toppings.TomatoSauce);
        toppingList.add(Toppings.Mozzarella);
        toppingList.add(Toppings.Ham);
        toppingList.add(Toppings.Peperoni);
        toppingList.add(Toppings.Salami);
        toppingList.add(Toppings.Chicken);
        toppingList.add(Toppings.Beef);
        toppingList.add(Toppings.Mushroom);
        toppingList.add(Toppings.Bolognese);
        toppingList.add(Toppings.BearnaiseSauce);
        toppingList.add(Toppings.Pineapple);
        toppingList.add(Toppings.Olives);
        toppingList.add(Toppings.Banana);
    }

    //getters
    public String[] getPizzaList(){
       String[] out = new String[pizzaList.length];
        for (int i = 0; i < pizzaList.length; i++) {
            out[i] = pizzaList[i].toString();
        }
        return out;
    }

    public String[] getBeverageList(){
        String[] out = new String[beverageList.size()];
        for (int i = 0; i < out.length; i++) {
            out[i] = beverageList.get(i).toString();
        }
        return out;
    }

    public String[] getToppingsList(){
        String[] out = new String[toppingList.size()];
        for (int i = 0; i < out.length; i++) {
            out[i] = toppingList.get(i).toString();
        }
        return out;
    }

    public Pizza[] getPizzas(){
        return pizzaList;
    }

    public List<Beverage> getBeverages(){
        return beverageList;
    }
}
