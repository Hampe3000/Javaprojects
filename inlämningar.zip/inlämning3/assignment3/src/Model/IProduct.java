// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package Model;

public interface IProduct {//interface for the Product class
    ProductType getProductType();
    void setProductType(ProductType productType);
    String getName();
    void setName(String name);
    double getCost();
    void setCost(double cost);
}
