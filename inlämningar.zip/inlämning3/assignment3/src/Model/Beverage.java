// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package Model;

public class Beverage extends Product{
    private double alcoholContent;

    public Beverage(String name, double cost){//constructor taking 2 arguments calling the next constructor with 1 default
        this(name, cost, 0.0);
    }

    public Beverage(String name, double cost, double alcoholContent){//constructor taking all arguments
        this.setProductType(ProductType.Beverage);
        this.setName(name);
        this.setCost(cost);
        this.alcoholContent = alcoholContent;
    }

    public String toString(){//to string two options
        if(alcoholContent > 0){
            return getName() + " ," + alcoholContent + "%, " + getCost() + "kr";
        }
        else{
            return getName() + " ," + getCost() + "kr";
        }
    }
    //getter
    public double getAlcoholContent() {
        return alcoholContent;
    }

}
