// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package Model;

import java.util.ArrayList;
import java.util.List;

public class OrderManager {

    private List<Order> orders;
    private int orderNr;
    private int selectedOrder;

    public OrderManager(){
        orders = new ArrayList<Order>();
        orderNr = 1000;
        selectedOrder = -1;
    }

    public void addOrder(Order order){
        order.setId(orderNr);
        orders.add(order);
        orderNr++;
    }

    public boolean selectedOrder(int index){//changes the position of the cursor to point at an order
        if(index > -1 && index < orders.size()){
            selectedOrder = index;
            return true;
        }
        return false;
    }

    public Order getSelectedOrder(){//returns the currently selected order
        if(selectedOrder > -1){
            return orders.get(selectedOrder);
        }
        return null;
    }

    public String[] getInfoStrings(){//returns info about all the orders
        String[] out = new String[orders.size()];
        for (int i = 0; i < orders.size(); i++) {
            out[i] = orders.get(i).toString();
        }
        return out;
    }
}
