package Model;

public class Order {

    private Product[] item;
    private int[] count;
    private int id;
    private int numOfItems;
    private double totalCost;

    public Order(){
        item = new Product[20];
        count = new int[20];
        this.id = id;
        totalCost = 0.0;
        numOfItems = 0;
    }

    public void addItem(Product item, int count){
        if(numOfItems == this.item.length){
            increaseLists();
        }
        this.item[numOfItems] = item;
        this.count[numOfItems] = count;
        numOfItems++;
        calcTotalCost();
    }

    private void increaseLists(){//if the array would fill upp this expands it
        Product[] tempItem = new Product[item.length+1];
        int[] tempCount = new int[count.length+1];
        for (int i = 0; i < item.length; i++) {
            tempItem[i] = item[i];
            tempCount[i] = count[i];
        }
        item = tempItem;
        count = tempCount;
    }

    public boolean deleteItemAt(int index){
        if(index > -1 && index < numOfItems){
            for (int i = index; i < numOfItems-1; i++) {
                item[i] = item[i+1];
                count[i] = count[i+1];
            }
            item[numOfItems-1] = null;
            count[numOfItems-1] = 0;
            numOfItems--;
            calcTotalCost();
            return true;
        }
        return false;
    }

    private void calcTotalCost(){//calculates the total cost of the order
        totalCost = 0;
        for (int i = 0; i < numOfItems; i++) {
            totalCost += count[i] * item[i].getCost();
        }
    }

    public boolean containsFood(){//checks so that atleast one product is food
        boolean food = false;
        for (int i = 0; i < numOfItems; i++) {
            if(item[i].getProductType() == ProductType.Food){
                food = true;
                break;
            }
        }
        return food;
    }

    public String[] getInfo(){//returns the quantity name and cost of all items in the order
        String[] info = new String[numOfItems];
        for (int i = 0; i < numOfItems; i++) {
            info[i] = count[i] + " * " + item[i].getInfo();
        }
        return info;
    }

    public String toString(){
        return "Order " + id + ", number of items:" + numOfItems + ", Total: " + totalCost +"kr";
    }

    //setter & getter

    public void setId(int id) {
        this.id = id;
    }

    public double getTotalCost(){
        return totalCost;
    }
}
