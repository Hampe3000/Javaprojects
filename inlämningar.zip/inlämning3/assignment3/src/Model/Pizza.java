// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package Model;

import Model.Topping.Topping;

public class Pizza extends Product{

    private final int maxToppings = 10;
    private final double baseCost = 35.00;
    private int numOfToppings = 0;
    private Topping[] myToppings = new Topping[maxToppings];

    public Pizza(String name){//constructor
        setName(name);
        setCost(baseCost);
        setProductType(ProductType.Food);
    }


    private void calcCost(){//method for calculating the cost of the pizza
        double cost = baseCost;
        for (int i = 0; i < numOfToppings; i++) {
            cost += myToppings[i].getCost();
        }
        setCost(cost);
    }

    public boolean addTopping(Topping topping){
        if(numOfToppings < maxToppings){
            myToppings[numOfToppings] = topping;
            numOfToppings++;
            calcCost();
            return true;
        }
        return false;
    }

    public boolean removeToppingAt(int index){
        if(index > -1 && index < numOfToppings){
            for (int i = index; i < numOfToppings -1; i++) {
                myToppings[i] = myToppings[i+1];
            }
            myToppings[numOfToppings-1] = null;
            numOfToppings--;
            calcCost();
            return true;
        }
        return false;
    }

    public String toString(){
        String pizza = getName() + " ," + getCost() + "kr";
        for (int i = 0; i < numOfToppings; i++) {
            pizza += ", " + myToppings[i].getName();
        }
        return pizza;
    }
    //getter
    public Topping[] getToppings() {
        return myToppings;
    }
}
