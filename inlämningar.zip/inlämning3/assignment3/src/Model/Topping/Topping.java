// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package Model.Topping;

public class Topping {//pretty self-explanatory class and methods
    private String name;
    private double cost;

    public Topping(String name,double cost){
        this.name = name;
        this.cost = cost;
    }

    public String getName() {
        return name;
    }

    public double getCost() {
        return cost;
    }
    //used if your only interested in the name of the topping
    public String toString(){
        return name;
    }
    //used if both name and cost is needed
    public String getInfo(){
        return name + ", " + "Price: " + cost + "kr";
    }
}
