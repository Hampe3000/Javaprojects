// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package Model.Topping;


public interface Toppings {//an interface with preset toppings
    Topping TomatoSauce = new Topping("Tomato sauce", 10.00);
    Topping Mozzarella = new Topping("Mozzarella", 20.00);
    Topping Ham = new Topping("Ham", 20.00);
    Topping Pineapple = new Topping("Pineapple", 15.00);
    Topping Beef = new Topping("Beef", 40.00);
    Topping Mushroom = new Topping("Mushroom", 15.00);
    Topping BearnaiseSauce = new Topping("Bearnaise sauce", 15.00);
    Topping Salami = new Topping("Salami", 20.00);
    Topping Peperoni = new Topping("Peperoni", 20.00);
    Topping Olives = new Topping("Olives", 15.00);
    Topping Bolognese = new Topping("Bolognese", 30.00);
    Topping Chicken = new Topping("Chicken", 30.00);
    Topping Banana = new Topping("Banana", 15.00);
}
