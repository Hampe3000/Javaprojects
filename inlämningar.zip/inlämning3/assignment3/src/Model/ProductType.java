// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package Model;

public enum ProductType {
    Food,
    Beverage
}
