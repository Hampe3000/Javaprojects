// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package Model;

public abstract class Product implements IProduct{

    private String name;
    private ProductType productType;
    private double cost;

    public Product(){//default constructor setting default values for name and cost
        name = "Non specified product";
        cost = 0;
    }

    public String getInfo(){
        return name + ", " + cost + "kr";
    }

    @Override
    public ProductType getProductType() {
        return productType;
    }

    @Override
    public void setProductType(ProductType productType) {
        this.productType = productType;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public double getCost() {
        return cost;
    }

    @Override
    public void setCost(double cost) {
        this.cost = cost;
    }


}
