// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package Controller;

import View.MainFrame;

public class MainPrograming {

    public static void main(String[] args){
        Controller controller = new Controller();//starts the program
    }
}
