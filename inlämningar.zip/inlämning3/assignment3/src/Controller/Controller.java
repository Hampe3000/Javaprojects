// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package Controller;

import Model.*;
import Model.Topping.Topping;
import View.MainFrame;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class Controller {

    private OrderManager orderManager;
    private MainFrame view;
    private Order currentOrder;
    private Pizza customPizza;
    private Menu menu;
    private boolean itemsRFood;

    public Controller(){//default constructor setting upp the view and asking user for age
        view = new MainFrame(600, 400, this);
        orderManager = new OrderManager();
        currentOrder = new Order();
        menu = new Menu(view.getBool());
        itemsRFood = false;
    }

    public void showPizzas(){//displays the pizza menu in the left panel
        view.getMainPanel().getlPanel().setMenu(menu.getPizzaList());
        itemsRFood = true;
    }

    public void showDrinks(){//displays the drink menu in the left panel
        view.getMainPanel().getlPanel().setMenu(menu.getBeverageList());
        itemsRFood = false;
    }

    public void addToOrder() {//adds the selected item to the order and asks how many should be added
        int index = view.getMainPanel().getlPanel().getSelectedIndex();
        if (index != -1) {
            if (itemsRFood) {
                Pizza[] pizzaToAdd = menu.getPizzas();
                if (index >= pizzaToAdd.length) {
                    //todo fix custom pizza frame and all that jazz
                    customPizza = new Pizza("Custom");
                } else {
                    currentOrder.addItem(pizzaToAdd[index], view.getInt());
                }
            } else {
                List<Beverage> beverageToAdd = menu.getBeverages();
                currentOrder.addItem(beverageToAdd.get(index), view.getInt());
            }
            updateOrderInfo();
        }
    }

    private void updateOrderInfo(){//update the order info in the right panel
        view.getMainPanel().getrPanel().setOrderList(currentOrder.getInfo());
        view.getMainPanel().getrPanel().setPrice(currentOrder.getTotalCost());
    }

    public void placeOrder(){//adds the current order to the order manager and starts a new order
        boolean ok = currentOrder.containsFood();
        if(ok){
            orderManager.addOrder(currentOrder);
            currentOrder = new Order();
            updateOrderInfo();
            String[] clear = new String[1];
            view.getMainPanel().getlPanel().setMenu(clear);
            view.getMainPanel().getrPanel().setOrderHistoryList(orderManager.getInfoStrings());
            menu = new Menu(view.getBool());
        }
        else{
            view.showErrorMessage("A order must contain at least one pizza");
        }
    }

    public void viewHistory(){//displays an old order
        int index = view.getMainPanel().getrPanel().getIndex();
        if(index >= 0){
            orderManager.selectedOrder(index);
            Order oldOrder = orderManager.getSelectedOrder();
            view.displayOldOrder(oldOrder.toString(), oldOrder.getInfo());
        }
    }

}
