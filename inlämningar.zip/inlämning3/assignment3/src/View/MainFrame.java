// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package View;

import Controller.Controller;

import javax.swing.*;


public class MainFrame extends JFrame {
    private MainPanel mainPanel;
    private Controller controller;

    public MainFrame(int width, int height, Controller controller) {
        super("Restaurant");
        this.setResizable(false);
        this.setSize(width, height);
        this.controller = controller;
        this.mainPanel = new MainPanel(width, height, controller);
        this.setContentPane(mainPanel);
        this.setVisible(true);

    }


    public MainPanel getMainPanel() {
        return mainPanel;
    }

    public void setMainPanel(MainPanel mainPanel) {
        this.mainPanel = mainPanel;
    }

    public void showErrorMessage(String message){
        JOptionPane.showMessageDialog(null, message, "Something went wrong", JOptionPane.ERROR_MESSAGE);
    }

    public int getInt(){//popup that asks for a int
        boolean done = false;
        int ret = -1;
        do{
            String intText = JOptionPane.showInputDialog(null, "Please specify the amount you would like to add", JOptionPane.INFORMATION_MESSAGE);
            try {
                ret = Integer.parseInt(intText);
                done = ret > 0;
                if(!done) showErrorMessage("The number must be grater than 0!");
            }
            catch (NumberFormatException e){
                showErrorMessage("Invalid input! Please provide a whole number grater than zero.");
            }
        }while(!done);
        return ret;
    }

    public void displayOldOrder(String basicInfo, String[] infoStrings){//displays an old order in a popup
        JOptionPane.showInputDialog(null, "", basicInfo, JOptionPane.INFORMATION_MESSAGE,null, infoStrings, infoStrings[0]);
    }

    public boolean getBool(){//popup that asks for the users age
        int bollInt = JOptionPane.showConfirmDialog(null, "18?", "Are you 18 years or older?", JOptionPane.YES_NO_OPTION);
        if(bollInt == 0){
            return true;
        }
        else{
            return false;
        }
    }
}
