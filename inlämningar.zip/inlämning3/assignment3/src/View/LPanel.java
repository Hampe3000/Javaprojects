// Hampus Oxenholt
// ai7546
//Utbildning Datateknik
// 15/12-2021
package View;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class LPanel extends JPanel{
    private JList<Object> menu;
    private JButton showDrinks;
    private JButton showFood;
    private JButton addToOrder;
    private JLabel title;

    private int width;
    private int height;
    private Controller controller;

    public LPanel(int width, int height, Controller controller) {
        this.setLayout(null);
        this.controller = controller;
        this.width = width;
        this.height = height;
        this.setSize(width, height);
        setLocation(0, 0);
        setUp();
    }

    public void setUp() {//sets upp the panel
        title = new JLabel("MAU'S Pizzeria");
        title.setLocation((width / 2) - 45, 0);
        title.setSize(90, 20);
        this.add(title);

        menu = new JList<>();
        menu.setLocation(0, 23);
        menu.setSize(width, height - 100);
        this.add(menu);


        showFood = new JButton("Mat");
        showFood.setEnabled(true);
        showFood.setSize(width / 3, 30);
        showFood.setLocation(0, height - 75);
        //showFood.addActionListener(l -> controller.showPizzas());
        this.add(showFood);

        showDrinks = new JButton("Drickor");
        showDrinks.setEnabled(true); // Om du ska köra för VG ändrar du denna till True annars kan du skippa allt med drink att göra
        showDrinks.setSize(width / 3, 30);
        showDrinks.setLocation(width / 3, height - 75);
        this.add(showDrinks);

        addToOrder = new JButton("Lägg till");
        addToOrder.setEnabled(true);
        addToOrder.setSize(width / 3, 30);
        addToOrder.setLocation(width - (width / 3), height - 75);
        this.add(addToOrder);
        addListeners();
    }

    private void addListeners(){
        ActionListener listener = new ButtonActionListeners();

        showFood.addActionListener(listener);
        showDrinks.addActionListener(listener);
        addToOrder.addActionListener(listener);
    }

    class ButtonActionListeners implements ActionListener
    {

        public void actionPerformed(ActionEvent e){//redirects to controller to execute choices

           if (e.getSource() == showFood)
                controller.showPizzas();
            else if (e.getSource()== showDrinks)
                controller.showDrinks();
            else if (e.getSource() == addToOrder)
                controller.addToOrder();


        }
    }

    //getters & setters

    public JList<Object> getMenu() {
        return menu;
    }

    public int getSelectedIndex(){
        return this.menu.getSelectedIndex();
    }

    public void setMenu(String[] menu) {
        this.menu.setListData(menu);
    }

    public JButton getShowDrinks() {
        return showDrinks;
    }

    public void setShowDrinks(JButton showDrinks) {
        this.showDrinks = showDrinks;
    }

    public JButton getShowFood() {
        return showFood;
    }

    public void setShowFood(JButton showFood) {
        this.showFood = showFood;
    }

    public JButton getAddToOrder() {
        return addToOrder;
    }

    public void setAddToOrder(JButton addToOrder) {
        this.addToOrder = addToOrder;
    }

    public JLabel getTitle() {
        return title;
    }

    public void setTitle(JLabel title) {
        this.title = title;
    }

    @Override
    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
