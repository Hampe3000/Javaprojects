//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package View;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelLeft extends JPanel implements ActionListener {
    private Controller controller;
    private JButton resetButton;
    private JList highScore;
    private JLabel highScoreTitle;

    public PanelLeft(Controller controller) {
        this.setLayout(new GridLayout(3, 1));
        this.controller = controller;
        this.setLocation(0,-50);
        this.setSize(190, 550);

        //Highscore title setup
        highScoreTitle = new JLabel("LEGENDARY COMMANDERS:");
        highScoreTitle.setFont(new Font("Serif", Font.BOLD, 13));
        highScoreTitle.setLocation(20, 15);
        this.add(highScoreTitle);

        //Highscore list setup
        highScore = new JList();
        highScore.setSize(80, 300);
        highScore.setLocation(10, 40);
        this.add(highScore);

        //Resetbutton setup
        resetButton = new JButton("WITHDRAW(reset)");
        resetButton.addActionListener(this);
        resetButton.setSize(5,20);
        resetButton.setLocation(10, 450);
        this.add(resetButton);
    }

    //Update scoreboard
    public void updateScoreBoard(String[] scoreBoard){
        highScore.setListData(scoreBoard);
    }

    //Actionlistener resets game
    @Override
    public void actionPerformed(ActionEvent e) {
        controller.reset();

    }
}
