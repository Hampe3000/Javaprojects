//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package View;

import Controller.Controller;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import java.awt.*;

    public class MainPanel extends JPanel {
        //private PanelNorth pnlNorth;
        private PanelCenter pnlCenter;
        private PanelLeft pnlLeft;
        private PanelRight pnlRight;
        private PanelNorth pnlNorth;
        private Controller controller;

        public MainPanel(Controller controller) {
            super(null);
            this.controller = controller;
            this.setSize(800, 500);
            setupPanel();
        }

        private void setupPanel() {
           /* BorderLayout layout = new BorderLayout();
            setLayout(layout);
            Border border = this.getBorder();
            //Let the panel have a border, 10 pixels on all sides
            Border margin = BorderFactory.createEmptyBorder(10, 10, 10, 10);
            setBorder(new CompoundBorder(border, margin));

            /*score and player name
            pnlNorth = new PanelNorth(controller);
            add(pnlNorth, BorderLayout.NORTH);
            */

            // Scoreboard on western part of gui
            pnlLeft = new PanelLeft (controller);
            add(pnlLeft);

            //name & score
            pnlNorth = new PanelNorth();
            add(pnlNorth);
            //board at center of gui
            pnlCenter = new PanelCenter (controller);
            add(pnlCenter);

            //Rules on the eastern part of MainPanel
            pnlRight = new PanelRight(controller);
            add(pnlRight);
        }


        public void updateButton(int collum, int row, int color) {
            pnlCenter.updateButton(collum, row, color);
        }

        public void reset() {
            pnlCenter.reset();
        }

        public void setScore(int score){pnlNorth.setScore(score);}

        public void updateScoreBoard(String[] scoreBoard){pnlLeft.updateScoreBoard(scoreBoard);}

        public void setPlayerName(String playerName){pnlNorth.setPlayerName(playerName);}

        public void disableAll(){
            pnlCenter.disableAll();
        }
}
