//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package View;
import Controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelCenter extends JPanel implements ActionListener {
    private Controller controller;
    private JButton[][] buttons;


    public PanelCenter(Controller controller){
        this.controller = controller;
        this.setLayout(new GridLayout(10,10));
        setSize(390, 400);
        setLocation(200,40);
        createComponents();
    }


    private void createComponents(){
        //Create buttons
        buttons = new JButton[10][10];

        //GridLayout layout = new GridLayout(10, 10);
        //setLayout(layout);
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                buttons[i][j] = new JButton(" ");
                buttons[i][j].setSize(10,10);
                buttons[i][j].setLocation(10+(i*10), 40+(j*10));
                buttons[i][j].setBackground(Color.GREEN);
                buttons[i][j].addActionListener(this);
                add(buttons[i][j]);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        for (int i = 0; i < 10; i++){
            for (int j = 0; j < 10; j++) {
                if (buttons[i][j].equals(button)) {
                    controller.shot(i, j);
                    break;
                }
            }
        }
    }


    //Updates the pressed button
    public void updateButton(int row, int col, int color){
        switch(color){
            case 1:
                buttons[row][col].setBackground(Color.BLUE);
                break;
            case 2:
                buttons[row][col].setBackground(Color.RED);
                break;
            case 3:
                buttons[row][col].setBackground(Color.BLACK);
                break;
        }
        buttons[row][col].setEnabled(false);
    }

    //Reset the buttons (new game)
    public void reset(){
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                buttons[i][j].setEnabled(true);
                buttons[i][j].setBackground(Color.GREEN);
            }
        }
    }
    public void disableAll() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                buttons[i][j].setEnabled(false);
            }
        }
    }
}
