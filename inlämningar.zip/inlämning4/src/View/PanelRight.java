//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package View;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;
public class PanelRight extends JPanel{
    private JLabel rules;
    private JLabel lblFiller;
    private JLabel green;
    private JLabel blue;
    private JLabel red;
    private JLabel black;
    private JButton btnGreen;
    private JButton btnBlue;
    private JButton btnRed;
    private JButton btnBlack;

    public PanelRight(Controller controller){
        this.setLayout(new GridLayout(5,2));
        setSize(180, 480);
        setLocation(600,0);

        rules = new JLabel("Radar 101");
        rules.setFont(new Font("Serif", Font.BOLD, 20));
        rules.setLocation(15, 10);
        add(rules);

        lblFiller = new JLabel(" ");
        add(lblFiller);

        btnGreen = new JButton();
        btnGreen.setSize(10,10);
        btnGreen.setLocation(7,20);
        btnGreen.setBackground(Color.GREEN);
        btnGreen.setEnabled(false);
        add(btnGreen);

        green = new JLabel("Unknown");
        green.setLocation(15, 100);
        add(green);

        btnBlue = new JButton();
        btnBlue.setSize(10,10);
        btnBlue.setLocation(7,30);
        btnBlue.setBackground(Color.BLUE);
        btnBlue.setEnabled(false);
        add(btnBlue);

        blue = new JLabel("Clear");
        blue.setLocation(20,30);
        add(blue);

        btnRed = new JButton();
        btnRed.setSize(10,10);
        btnRed.setLocation(7,40);
        btnRed.setBackground(Color.RED);
        btnRed.setEnabled(false);
        add(btnRed);

        red = new JLabel("Enemy hit");
        red.setLocation(20, 40);
        add(red);

        btnBlack = new JButton();
        btnBlack.setSize(10,10);
        btnBlack.setLocation(600,0);
        btnBlack.setBackground(Color.BLACK);
        btnBlack.setEnabled(false);
        add(btnBlack);

        black = new JLabel("Enemy sunk");
        black.setLocation(20, 50);
        add(black);

    }
}
