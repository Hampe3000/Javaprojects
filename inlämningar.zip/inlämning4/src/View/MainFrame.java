//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package View;
import javax.swing.*;
import Controller.*;



public class MainFrame{
    private JFrame frame;
    private MainPanel panel;
    Controller controller;

    private int width = 800;
    private int height = 500;

    public MainFrame(Controller controller) {
        this.controller = controller;

        frame = new JFrame("Total Ship Wars!");
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(width, height);
        frame.setLocation(200, 200);

        this.panel = new MainPanel(controller);
        frame.add(panel);
        frame.setContentPane(panel);
        //frame.pack();
        frame.setVisible(true);
    }

    public void message(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public void updateButton(int column, int row, int color) {
        panel.updateButton(column, row, color);
    }
    //rename to selected, case switches colors.

    public String inputWindow(String msg){
        return JOptionPane.showInputDialog(frame, msg);
    }
    //input for player name.

    public void reset() {
        panel.reset();
    }
    //reset buttons.

    public void updateScore(int score){panel.setScore(score);}

    public void setPlayerName(String playerName){panel.setPlayerName(playerName);}

    public void updateScoreBoard(String[] scoreBoard){
        panel.updateScoreBoard(scoreBoard);
    }

    public boolean playAgain(){//popup that asks for restart of the game
        int bollInt = JOptionPane.showConfirmDialog(null, "Would you like to play again? ", "Rematch?", JOptionPane.YES_NO_OPTION);
        if(bollInt == 0){
            return true;
        }
        else{
            return false;
        }
    }

    public void disableAll(){
        panel.disableAll();
    }
}