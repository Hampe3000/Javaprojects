//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package View;

import javax.swing.*;
import java.awt.*;

public class PanelNorth extends JPanel {
    private JLabel currentCommander;
    private JLabel playerName;
    private JLabel scoreValue;
    private JLabel score;

    public PanelNorth(){
        this.setLayout(new GridLayout(2,2));
        setSize(390, 30);
        setLocation(200,0);

        //Create labels
        currentCommander = new JLabel("Current Commander");
        currentCommander.setLocation(20, 10);
        add(currentCommander);

        playerName = new JLabel(""); // get player name
        playerName.setLocation(50,10);
        add(playerName);

        score = new JLabel("Score");
        score.setLocation(20, 20);
        add(score);

        scoreValue = new JLabel(""); //get score value
        scoreValue.setLocation(35, 20);
        add(scoreValue);
    }
    public void setPlayerName(String playerName){
        this.playerName.setText(playerName);
    }

    public void setScore(int score) {
        this.scoreValue.setText(Integer.toString(score));
    }
}
