//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package Model;

public enum Shiptype {
    Ubåt,//2
    Torpedbåt,//3
    Jagare,//3
    Kryssare,//2
    Slagskepp//1
}
