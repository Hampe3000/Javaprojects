//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package Model;

public interface Ships {
    Ship SS_FlagShip = new Ship("SS FlagShip", 5);
    Ship Big_Boy = new Ship("Big Boy", 4);
    Ship Eddy = new Ship("Eddy", 4);
    Ship Mine_Sweeper = new Ship("Mine Sweeper", 3);
    Ship Destructor = new Ship("Destructor", 3);
    Ship Terminator = new Ship("Terminator", 3);
    Ship Huntsman = new Ship("Huntsman", 2);
    Ship Fishing_Boat = new Ship("Fishing Boat", 2);
    Ship Scout = new Ship("Scout", 2);
    Ship Atlantis = new Ship("Atlantis", 1);
    Ship Poseidon = new Ship("Poseidon", 1);
}
