//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package Model;

public class ScoreBoard {
    private String[] names;
    private int[] scores;

    public ScoreBoard(){
        names = new String[]{"Anna", "Bengt", "Clara", "David", "Ellen", "Fredrick", "Gwen", "Harry", "Isabella", "Jon"};
        scores = new int[]{100, 100, 100, 100, 100, 100, 100, 100, 100, 100};
    }
    //metod som sorterar arrayerna med avseende på score i växande ordning
    private void sort(){
        int[] sortedArray = new int[scores.length];
        String[] sortedNames = new String[names.length];
        for (int i=0; i<sortedArray.length; i++)
        {
            int curentMinValue=999;
            int curentMinIndex=-1;
            for (int a=0; a<scores.length; a++)
            {
                if(scores[a]<curentMinValue && scores[a] !=-1)
                {
                    curentMinValue=scores[a];
                    curentMinIndex= a;
                }
            }
            sortedArray[i] = scores[curentMinIndex];
            sortedNames[i] = names[curentMinIndex];
            scores[curentMinIndex]=-1;
        }
        scores = sortedArray;
        names = sortedNames;
    }
    //metod som tar en string och en int som parametrar och beslutar om dessa ska läggas till i listan
    public boolean addToScoreBoard(int score, String name){
        if (duble(score, name)){
            return true;
        }
        else{
            if(score < scores[scores.length-1]){
                scores[scores.length-1] = score;
                names[scores.length-1] = name;
                sort();
                return true;
            }
            else{
                return false;
            }
        }
    }
    //metod som tar en string och en int som lägger till om inten är den samma som redan finns i listan
    private boolean duble(int score, String name){
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] == score){
                names[i] += " & " + name;
                return true;
            }
        }
        return false;
    }
    //returnerar scoreboard som en array strings
    public String[] getScoreBoard(){
        String[] scoreBoard = new String[scores.length];
        for (int i = 0; i < scoreBoard.length; i++) {
            scoreBoard[i] = i+1 + ". " + scores[i] + " " + names[i];
        }
        return scoreBoard;
    }
}
