//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package Model;

public class Ship {
    private int length;
    private String name;
    private int hullPoints;
    private Shiptype shiptype;
    private boolean sunk = false;

    public Ship(String name, int length){
        this.length = length;
        hullPoints = length;
        this.name = name;
        setType();
    }
    //metod som bestämmer vilken typp av skepp det är
    private void setType(){
        switch (length){
            case 1:
                shiptype = Shiptype.Ubåt;
                break;
            case 2:
                shiptype = Shiptype.Torpedbåt;
                break;
            case 3:
                shiptype = Shiptype.Jagare;
                break;
            case 4:
                shiptype = Shiptype.Kryssare;
                break;
            case 5:
                shiptype = Shiptype.Slagskepp;
                break;
        }
    }
    //metod som dekrementerar hullPoints och returnerar shiptype
    public Shiptype hit(){
        hullPoints--;
        return shiptype;
    }
    //som returnera skeppets status
    public boolean isSunk(){
        if(hullPoints <=0){
            sunk = true;
        }
        return sunk;
    }
    //reparerar skeppet
    public void reset(){
        hullPoints = length;
        sunk = false;
    }

    //getters
    public String getName(){
        return name;
    }

    public int getLength() {return length;}
}
