//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package Model;

import java.util.Random;

public class PlayField implements Ships{
    private Ship[][] board;
    private final Ship[] list = new Ship[]{Ships.SS_FlagShip,
            Ships.Big_Boy, Ships.Eddy, Ships.Destructor, Ships.Mine_Sweeper,
            Ships.Terminator, Ships.Huntsman, Ships.Fishing_Boat, Ships.Scout,
            Ships.Poseidon, Ships.Atlantis};
    private Random random = new Random();

    public PlayField(int map){//0 = random
        resetShips();
        board = new Ship[10][10];
        switch (map){
            case 1:
                int row = 0;
                int col =0;
                for (int i = 1; i < list.length; i++) {
                    for (int j = 0; j < list[i].getLength(); j++) {
                        board[row][col+j] = list[i];
                    }
                    row++;
                }
                col = 7;
                for (int i = 0; i < list[0].getLength(); i++) {
                    board[i][col] = list[0];
                }
                break;
            case 0:
                generateRandomMap();
                break;
        }
    }
    //metod tar två ints som parametrar och returnerar vilken typ av skepp som träffats
    public Shiptype hit(int r, int c){
        if (board[r][c] != null){
            return board[r][c].hit();
        }
        else{
            return null;
        }
    }

    //metod tar två ints och returnerar om positionen inehåller ett sänkt skepp
    public boolean sunk(int r, int c){
        if (board[r][c] != null){
            return board[r][c].isSunk();
        }
        else{
            return false;
        }
    }
    //metoden resetar alla skepp
    private void resetShips(){
        for (int i = 0; i < list.length; i++) {
            list[i].reset();
        }
    }

    //metod som slumpar utt skeppen på spelplanen
    private void generateRandomMap(){

            for (int i = 0; i < list.length; i++) {
                boolean done = false;
                while(!done){
                    int row = random.nextInt(10);//selects a number between 0-9
                    int col = random.nextInt(10);//same as row
                    boolean ok = true;
                    switch (random.nextInt(2)){//determines if the ship will try to build vertically or horizontally
                        case 0://vertical building down
                            for (int j = 0; j < list[i].getLength(); j++) {
                                if(row+j >9 || board[row+j][col] !=null){
                                    ok = false;
                                    break;
                                }
                            }
                            if(ok) {
                                for (int j = 0; j < list[i].getLength(); j++) {
                                    board[row + j][col] = list[i];
                                }
                                done = true;
                            }
                            break;

                        case 1://horizontal building lef to right
                            for (int j = 0; j < list[i].getLength(); j++) {
                                if(col+j >9 || board[row][col+j] !=null){
                                    ok = false;
                                    break;
                                }
                            }
                            if(ok) {
                                for (int j = 0; j < list[i].getLength(); j++) {
                                    board[row][col+j] = list[i];
                                }
                                done = true;
                            }
                            break;
                    }

                }
            }
    }
    //metoden kollar om alla skepp är sänkta
    public boolean allSunk(){
        boolean allSunk = true;
        for (Ship ship : list) {
            if (!ship.isSunk()) {
                allSunk = false;
                break;
            }
        }
        return allSunk;
    }
    //metoden tar ett ship som parameter returnerar en två dimensionel int array med samtliga kordinater detta skepp befiner sig på
    public int[][] returnFullShipCoordinates(Ship wantedShip){
        int[][] coordinates = new int[wantedShip.getLength()][2];
        int length = 0;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if(board[i][j] == wantedShip){
                    coordinates[length][0] = i;
                    coordinates[length][1] = j;
                    length++;
                }
            }
        }
        return coordinates;
    }
    //metoden tar två ints som parametrar och returnerar skeppet som ligger på den positionen
    public Ship getShipAt(int row, int col){
        return board[row][col];
    }
}
