//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package Controller;

import Model.*;
import View.*;

public class Controller {
    private MainFrame view;
    //private Ship[][] playField;
    private PlayField board;
    private String playerName;
    private int shots;
    private ScoreBoard scoreBoard;

    public Controller(){
        view = new MainFrame(this);
        board = new PlayField(0);
        playerName = view.inputWindow("Please enter your name");
        shots = 0;
        scoreBoard = new ScoreBoard();

        view.setPlayerName(playerName);
        view.updateScore(shots);
        view.updateScoreBoard(scoreBoard.getScoreBoard());
    }
    //metoden tar två integers som parametrar och skjuter sedan på positionen som anges av dessa
    //metoden returnerar ett meddelande och uppdaterar knappen/knapparna
    //kan fråga om spelet ska reseta
    public void shot(int row, int col){
        shots++;
        view.updateScore(shots);
        Shiptype currShip = board.hit(row, col);
        if(currShip != null){
            if(board.sunk(row, col)){
                // update all buttons of that ship
                int[][] array = board.returnFullShipCoordinates(board.getShipAt(row, col));
                for(int i = 0; i < array.length; i++){
                    view.updateButton(array[i][0], array[i][1], 3);
                }
                //you sunk the getShipName
                view.message("You´ve sunk the " + board.getShipAt(row, col).getName(), "Ship sunk!");


            }
            else{
                //update the specific button
                view.updateButton(row, col, 2);
                //you hit a currShip
                view.message("You´ve hit a " + currShip.name(), "Hit!");
            }
        }
        else{
            //update the specific button
            view.updateButton(row, col, 1);
        }
        if(board.allSunk()){
            //disable all buttons
            view.disableAll();
            if(scoreBoard.addToScoreBoard(shots, playerName)){
                //great job
                view.message("Great job! New high score!", "Legendary!");
            }
            else{
                //better luck next time
                view.message("Less than we expected.", "Better luck next time...");
            }
            view.updateScoreBoard(scoreBoard.getScoreBoard());
            //reset?
            if(view.playAgain()){
                reset();
            }

        }
    }

    //metod som nollställer spellplanen och ber om nytt spelarnamn samt uppdaterar guit
    public void reset(){
        playerName = view.inputWindow("Please enter your name ");
        shots = 0;
        board = new PlayField(0);
        //clear all buttons
        view.reset();
        view.updateScore(shots);
        view.setPlayerName(playerName);
    }
}
