//Authors: Hampus Oxenholt ai7546 & Robin Zhang am3099
//Study Program: DT
//Last modified: 06/01-2022
package Controller;

public class Main {

    public static void main(String[] args) {
        Controller c = new Controller();
    }
}
